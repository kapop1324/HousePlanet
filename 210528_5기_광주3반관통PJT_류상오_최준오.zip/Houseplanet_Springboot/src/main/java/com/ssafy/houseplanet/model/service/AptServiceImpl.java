package com.ssafy.houseplanet.model.service;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.houseplanet.model.Apart;
import com.ssafy.houseplanet.model.Baseaddress;
import com.ssafy.houseplanet.model.BoardDto;
import com.ssafy.houseplanet.model.CityDto;
import com.ssafy.houseplanet.model.CommentDto;
import com.ssafy.houseplanet.model.DongDto;
import com.ssafy.houseplanet.model.GugunDto;
import com.ssafy.houseplanet.model.HighratingDto;
import com.ssafy.houseplanet.model.mapper.AptDao;


@Service
public class AptServiceImpl implements AptService {

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public List<Baseaddress> getCityList2() throws SQLException {
		return sqlSession.getMapper(AptDao.class).getCityList2();
	}

	@Override
	public List<Baseaddress> getGugunList2(String cityCode) throws SQLException {
		return sqlSession.getMapper(AptDao.class).getGugunList2(cityCode);
	}

	@Override
	public List<Baseaddress> getDongList2(String gugunCode) throws SQLException {
		return sqlSession.getMapper(AptDao.class).getDongList2(gugunCode);
	}

	@Override
	public List<CityDto> getCityList() throws SQLException {
		return sqlSession.getMapper(AptDao.class).getCityList();
	}

	@Override
	public List<GugunDto> getGugunList(String city) throws SQLException {
		return sqlSession.getMapper(AptDao.class).getGugunList(city);
	}

	@Override
	public List<DongDto> getDongList(String gugun) throws SQLException {
		return sqlSession.getMapper(AptDao.class).getDongList(gugun);
	}

	@Override
	public boolean register(BoardDto boarddto) throws SQLException {
		
		return sqlSession.getMapper(AptDao.class).register(boarddto);
	}

	@Override
	public List<BoardDto> review_list() throws SQLException {
		
		return sqlSession.getMapper(AptDao.class).review_list();
	}

	@Override
	public BoardDto review_detail(int idx) throws SQLException {
		
		return sqlSession.getMapper(AptDao.class).review_detail(idx);
	}

	@Override
	public boolean reg_comment(CommentDto commentdto) throws SQLException {
		
		return sqlSession.getMapper(AptDao.class).reg_comment(commentdto);
	}

	@Override
	public List<CommentDto> get_comment(int preidx) throws SQLException {
		
		return sqlSession.getMapper(AptDao.class).get_comment(preidx);
	}

	@Override
	public boolean delete_review(int idx) {
		
		return sqlSession.getMapper(AptDao.class).delete_review(idx);
	}

	@Override
	public boolean modify_review(BoardDto boarddto) {
		
		return sqlSession.getMapper(AptDao.class).modify_review(boarddto);
	}

	@Override
	public List<HighratingDto> get_highrating() throws SQLException {
		
		return sqlSession.getMapper(AptDao.class).get_highrating();
	}

}
