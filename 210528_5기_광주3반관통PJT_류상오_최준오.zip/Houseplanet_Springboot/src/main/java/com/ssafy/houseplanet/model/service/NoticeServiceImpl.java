package com.ssafy.houseplanet.model.service;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.houseplanet.model.Apart;
import com.ssafy.houseplanet.model.Baseaddress;
import com.ssafy.houseplanet.model.BoardDto;
import com.ssafy.houseplanet.model.CityDto;
import com.ssafy.houseplanet.model.CommentDto;
import com.ssafy.houseplanet.model.DongDto;
import com.ssafy.houseplanet.model.GugunDto;
import com.ssafy.houseplanet.model.NoticeDto;
import com.ssafy.houseplanet.model.mapper.AptDao;
import com.ssafy.houseplanet.model.mapper.NoticeDao;


@Service
public class NoticeServiceImpl implements NoticeService {

	@Autowired
	private SqlSession sqlsession;

	@Override
	public boolean reg_notice(NoticeDto noticedto) {
		
		return sqlsession.getMapper(NoticeDao.class).reg_notice(noticedto);
	}

	@Override
	public List<NoticeDto> get_notice() {
		
		return sqlsession.getMapper(NoticeDao.class).get_notice();
	}

	@Override
	public NoticeDto search_notice(int idx) {
		
		return sqlsession.getMapper(NoticeDao.class).search_notice(idx);
	}

	@Override
	public boolean delete_notice(int idx) {
		
		return sqlsession.getMapper(NoticeDao.class).delete_notice(idx);
	}

	@Override
	public boolean modify_notice(NoticeDto noticedto) {
		
		return sqlsession.getMapper(NoticeDao.class).modify_notice(noticedto);
	}
	
	

}
