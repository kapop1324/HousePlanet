package com.ssafy.houseplanet.model.service;

import java.util.List;
import java.util.Map;

import com.ssafy.houseplanet.model.UserDto;


public interface UserService {
	
	public boolean register(UserDto userdto);
	public UserDto login(Map map);
	
}
