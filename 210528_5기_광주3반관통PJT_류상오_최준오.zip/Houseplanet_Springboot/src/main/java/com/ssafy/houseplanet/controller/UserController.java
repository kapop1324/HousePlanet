package com.ssafy.houseplanet.controller;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.houseplanet.model.UserDto;
import com.ssafy.houseplanet.model.service.UserService;


@RestController
@RequestMapping("/user")
@CrossOrigin("*")
public class UserController {
	
	@Autowired
	private UserService userservice;
	
	private static final String SUCCESS = "success";
	private static final String FAIL = "fail";
	
	@PostMapping("/register")
	public ResponseEntity<String> register(@RequestBody UserDto userdto){
		
		if(userservice.register(userdto)) {
			return new ResponseEntity<String>(SUCCESS,HttpStatus.OK);
		}
		
		return new ResponseEntity<String>(FAIL,HttpStatus.NO_CONTENT);
		
	}
	
	@GetMapping("/login")
	public ResponseEntity<UserDto> login(@RequestParam Map map){
		
		UserDto dto = userservice.login(map);
		if(dto != null) {
			return new ResponseEntity<UserDto>(dto,HttpStatus.OK);
		}
		
		return new ResponseEntity<UserDto>(dto,HttpStatus.NO_CONTENT);

	}
	

}
