package com.ssafy.houseplanet.controller;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.houseplanet.model.Baseaddress;
import com.ssafy.houseplanet.model.BoardDto;
import com.ssafy.houseplanet.model.CityDto;
import com.ssafy.houseplanet.model.CommentDto;
import com.ssafy.houseplanet.model.DongDto;
import com.ssafy.houseplanet.model.GugunDto;
import com.ssafy.houseplanet.model.HighratingDto;
import com.ssafy.houseplanet.model.PagingDto;
import com.ssafy.houseplanet.model.UserDto;
import com.ssafy.houseplanet.model.service.AptService;




@RestController
@RequestMapping("/apt")
@CrossOrigin("*")
public class AptRestController {
	private static final Logger logger = LoggerFactory.getLogger(AptRestController.class);
	
	@Autowired
	private AptService aptService;
	
	@GetMapping(value="/city")
	public ResponseEntity<List<CityDto>> getCityList(){
		 System.out.println("1");
		try {
			List<CityDto> list = aptService.getCityList();
			return new ResponseEntity<List<CityDto>>(list, HttpStatus.OK);
		} catch (SQLException e) {
			e.printStackTrace(); 
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
	} 
	
	@GetMapping(value="/gugun/{city}")
	public ResponseEntity<List<GugunDto>> getGugunList(@PathVariable("city") String city){
		System.out.println("2");
		try {
			city = city.substring(0,2);
			List<GugunDto> list = aptService.getGugunList(city);
			return new ResponseEntity<List<GugunDto>>(list, HttpStatus.OK);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
	}
	
	@GetMapping(value="/dong/{gugun}")
	public ResponseEntity<List<DongDto>> getDongList(@PathVariable("gugun") String gugun){
		System.out.println("3");
		try {
			gugun = gugun.substring(0,4);
			List<DongDto> list = aptService.getDongList(gugun);
			return new ResponseEntity<List<DongDto>>(list, HttpStatus.OK);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
	}
	
	@PostMapping(value="/review")
	public ResponseEntity<String> register(@RequestBody BoardDto boarddto) {	
		
		try {
			if(aptService.register(boarddto)) {
				return new ResponseEntity<String>("success",HttpStatus.OK);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<String>("fail",HttpStatus.NO_CONTENT);
			
		}
		return new ResponseEntity<String>("fail",HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/review_list")
	public ResponseEntity<List<BoardDto>> register() {	
		
		
		try {
			List<BoardDto> list = aptService.review_list();
			if(list != null ) {
				return new ResponseEntity<List<BoardDto>>(list,HttpStatus.OK);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<List<BoardDto>>(HttpStatus.NO_CONTENT);
			
		}
		return new ResponseEntity<List<BoardDto>>(HttpStatus.NO_CONTENT);
	} 
	
	@GetMapping(value="/detail/{idx}")
	public ResponseEntity<BoardDto> getreviewdetail(@PathVariable("idx") int idx){
		
		try {
			 
			BoardDto dto = aptService.review_detail(idx);
			return new ResponseEntity<BoardDto>(dto, HttpStatus.OK);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
	}
	
	@PostMapping(value="/reg_comment")
	public ResponseEntity<String> register_comment(@RequestBody CommentDto commentdto) {
		try {
			if(aptService.reg_comment(commentdto)) {
				return new ResponseEntity<String>("success",HttpStatus.OK);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<String>("fail",HttpStatus.NO_CONTENT);
			
		}
		return new ResponseEntity<String>("fail",HttpStatus.NO_CONTENT);
	}
	
	@GetMapping(value="/get_comment/{preidx}")
	public ResponseEntity<List<CommentDto>> getcomment(@PathVariable("preidx") int preidx){
		
		try {
			
			List<CommentDto> list = aptService.get_comment(preidx);
			return new ResponseEntity<List<CommentDto>>(list, HttpStatus.OK);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
	}
	
	@DeleteMapping("/delete_review/{idx}")
	public ResponseEntity<String> delete_review(@PathVariable("idx") int idx){
		if(aptService.delete_review(idx)) {
			return new ResponseEntity<String>(HttpStatus.OK);
		}
		return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
	}
	
	@PutMapping("/modify_review")
	public ResponseEntity<String> modify_review(@RequestBody BoardDto boarddto){
		
		if(aptService.modify_review(boarddto)) {
			return new ResponseEntity<String>(HttpStatus.OK);
		}
		return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping(value="/city2")
	public ResponseEntity<List<Baseaddress>> getCityList2(){
		try {
			List<Baseaddress> list = aptService.getCityList2();
			return new ResponseEntity<List<Baseaddress>>(list, HttpStatus.OK);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
	}
	
	@GetMapping(value="/gugun2/{city}")
	public ResponseEntity<List<Baseaddress>> getGugunList2(@PathVariable("city") String city){
		try {
			List<Baseaddress> list = aptService.getGugunList2(city);
			return new ResponseEntity<List<Baseaddress>>(list, HttpStatus.OK);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
	}
	
	@GetMapping(value="/dong2/{gugun}")
	public ResponseEntity<List<Baseaddress>> getDongList2(@PathVariable("gugun") String gugun){
		try {
			List<Baseaddress> list = aptService.getDongList2(gugun);
			return new ResponseEntity<List<Baseaddress>>(list, HttpStatus.OK);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
	}
	
	@GetMapping(value="/highrating")
	public ResponseEntity<List<HighratingDto>> getHighrating(){
		try {
			List<HighratingDto> list = aptService.get_highrating();
			return new ResponseEntity<List<HighratingDto>>(list, HttpStatus.OK);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
	}
	
	
}
