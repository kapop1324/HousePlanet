package com.ssafy.houseplanet.model.mapper;

import java.util.List;
import java.util.Map;

import com.ssafy.houseplanet.model.UserDto;


public interface UserDao {
	
	public boolean register(UserDto userdto);
	public UserDto login(Map map);

}
