package com.ssafy.houseplanet.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.houseplanet.model.Apart;
import com.ssafy.houseplanet.model.Baseaddress;
import com.ssafy.houseplanet.model.BoardDto;
import com.ssafy.houseplanet.model.CityDto;
import com.ssafy.houseplanet.model.CommentDto;
import com.ssafy.houseplanet.model.DongDto;
import com.ssafy.houseplanet.model.GugunDto;
import com.ssafy.houseplanet.model.HighratingDto;
import com.ssafy.houseplanet.model.UserDto;


public interface AptService {
	
	public List<Baseaddress> getCityList2() throws SQLException;
	
	public List<Baseaddress> getGugunList2(String cityCode) throws SQLException;
	
	public List<Baseaddress> getDongList2(String gugunCode) throws SQLException;
	
	public List<CityDto> getCityList() throws SQLException;
	
	public List<GugunDto> getGugunList(String city) throws SQLException;
	
	public List<DongDto> getDongList(String gugun) throws SQLException;
	
	public boolean register(BoardDto boarddto) throws SQLException;
	
	public List<BoardDto> review_list() throws SQLException;
	
	public BoardDto review_detail(int idx) throws SQLException;
	
	public boolean reg_comment(CommentDto commentdto) throws SQLException;
	
	public List<CommentDto> get_comment(int preidx) throws SQLException;
	
	public List<HighratingDto> get_highrating() throws SQLException;
	
	public boolean delete_review(int idx);
	
	public boolean modify_review(BoardDto boarddto);
	
}
