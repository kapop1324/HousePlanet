package com.ssafy.houseplanet.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.houseplanet.model.Apart;
import com.ssafy.houseplanet.model.Baseaddress;
import com.ssafy.houseplanet.model.BoardDto;
import com.ssafy.houseplanet.model.CityDto;
import com.ssafy.houseplanet.model.CommentDto;
import com.ssafy.houseplanet.model.DongDto;
import com.ssafy.houseplanet.model.GugunDto;
import com.ssafy.houseplanet.model.NoticeDto;
import com.ssafy.houseplanet.model.UserDto;


public interface NoticeService {
	
	public boolean reg_notice(NoticeDto noticedto);
	public List<NoticeDto> get_notice();
	public NoticeDto search_notice(int idx);
	public boolean delete_notice(int idx);
	public boolean modify_notice(NoticeDto noticedto);
	
	
}
