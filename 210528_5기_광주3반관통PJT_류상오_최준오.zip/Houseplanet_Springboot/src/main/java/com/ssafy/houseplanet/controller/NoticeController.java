package com.ssafy.houseplanet.controller;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.houseplanet.model.Baseaddress;
import com.ssafy.houseplanet.model.BoardDto;
import com.ssafy.houseplanet.model.CityDto;
import com.ssafy.houseplanet.model.CommentDto;
import com.ssafy.houseplanet.model.DongDto;
import com.ssafy.houseplanet.model.GugunDto;
import com.ssafy.houseplanet.model.NoticeDto;
import com.ssafy.houseplanet.model.UserDto;
import com.ssafy.houseplanet.model.service.AptService;
import com.ssafy.houseplanet.model.service.NoticeService;




@RestController
@RequestMapping("/notice")
@CrossOrigin("*")
public class NoticeController {
	private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);
	
	@Autowired
	private NoticeService noticeservice;
	
	@PostMapping("/reg_notice")
	public ResponseEntity<String> reg_notice(@RequestBody NoticeDto noticedto){
		
		if(noticeservice.reg_notice(noticedto) == true) {
			return new ResponseEntity<String>("success",HttpStatus.OK);
		}
		return new ResponseEntity<String>("fail",HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/get_notice")
	public ResponseEntity<List<NoticeDto>> get_notice(){
		
		List<NoticeDto> list = noticeservice.get_notice();
		
		if(list != null) {
			return new ResponseEntity<List<NoticeDto>>(list,HttpStatus.OK);
		}
		
		return new ResponseEntity<List<NoticeDto>>(HttpStatus.NO_CONTENT);
	}
	@GetMapping("/search_notice/{idx}")
	public ResponseEntity<NoticeDto> search_notice(@PathVariable int idx){
		NoticeDto dto = noticeservice.search_notice(idx);
		
		if(dto != null) {
			return new ResponseEntity<NoticeDto>(dto,HttpStatus.OK);
		}
		
		return new ResponseEntity<NoticeDto>(HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping("/delete_notice/{idx}")
	public ResponseEntity<String> delete_notice(@PathVariable("idx") int idx){
		if(noticeservice.delete_notice(idx)) {
			return new ResponseEntity<String>(HttpStatus.OK);
		}
		return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
	}
	
	@PutMapping("/modify_notice")
	public ResponseEntity<String> modify_review(@RequestBody NoticeDto noticedto){
		System.out.println("??");
		if(noticeservice.modify_notice(noticedto)) {
			return new ResponseEntity<String>(HttpStatus.OK);
		}
		return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
	}
	
	
	
}
