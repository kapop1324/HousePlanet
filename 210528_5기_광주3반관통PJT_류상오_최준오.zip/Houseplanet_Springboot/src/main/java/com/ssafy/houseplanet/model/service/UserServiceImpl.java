package com.ssafy.houseplanet.model.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.houseplanet.model.UserDto;
import com.ssafy.houseplanet.model.mapper.UserDao;


@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private SqlSession sqlsession;

	@Override
	public boolean register(UserDto userdto) {
		
		return sqlsession.getMapper(UserDao.class).register(userdto);
	}

	@Override
	public UserDto login(Map map) {
		
		return sqlsession.getMapper(UserDao.class).login(map);
	}
	


}
