package com.ssafy.houseplanet.model;

public class PagingDto {
	
	private int pagenum;
	private int startpagenum;
	private int endpagenum;
	private int prev;
	private int next;
	private int select;
	
	public int getPagenum() {
		return pagenum;
	}
	public void setPagenum(int pagenum) {
		this.pagenum = pagenum;
	}
	public int getStartpagenum() {
		return startpagenum;
	}
	public void setStartpagenum(int startpagenum) {
		this.startpagenum = startpagenum;
	}
	public int getEndpagenum() {
		return endpagenum;
	}
	public void setEndpagenum(int endpagenum) {
		this.endpagenum = endpagenum;
	}
	public int getPrev() {
		return prev;
	}
	public void setPrev(int prev) {
		this.prev = prev;
	}
	public int getNext() {
		return next;
	}
	public void setNext(int next) {
		this.next = next;
	}
	public int getSelect() {
		return select;
	}
	public void setSelect(int select) {
		this.select = select;
	}

}
