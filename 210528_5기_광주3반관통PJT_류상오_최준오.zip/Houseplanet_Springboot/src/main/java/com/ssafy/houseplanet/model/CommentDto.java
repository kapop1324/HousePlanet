package com.ssafy.houseplanet.model;

import java.sql.Date;

public class CommentDto {
	
	private int idx;
	private int preidx;
	private String id;
	private String content;
	private Date regdate;
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public int getPreidx() {
		return preidx;
	}
	public void setPreidx(int preidx) {
		this.preidx = preidx;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

}
