<template>
    <div id="app">

      
      <header id="header" class="fixed-top d-flex align-items-center">
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
	   			<div class="container-fluid text-uppercase">
	   			<router-link class="navbar-brand" to="/">House Planet</router-link>
	    		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
	     			<span class="navbar-toggler-icon"></span>
	   		 	</button>
			    <div class="collapse navbar-collapse" id="navbarCollapse">
			      <ul class="navbar-nav mr-auto">
			        <li class="nav-item">
			          <router-link class="nav-link" to="/apt">아파트</router-link>
			        </li>
			        <li class="nav-item">
              		 <router-link class="nav-link"  v-on:click.native="change" to="/board" >게시판</router-link>
			        </li>
			        <li class="nav-item">
			          <router-link class="nav-link"  v-on:click.native="change" to="/notice" >공지사항</router-link>
			        </li>
			        <li class="nav-item">
			          <router-link class="nav-link" v-if="!this.$session.exists()" to="/login">로그인</router-link>
			        </li>
			        <li class="nav-item">
			          <router-link class="nav-link" to="/" v-if="this.$session.exists()"  v-on:click.native="logout">로그아웃</router-link>
			        </li>
			        <li class="nav-item">
			          <router-link class="nav-link" to="/register" v-if="!this.$session.exists()">회원가입</router-link>
			        </li>
			      </ul>
   				</div>
   				</div>
 			</nav>
    
      </header>
	  <div>
		  <router-view id="content"/>
	  </div>
       
	   <footer>
		   <div class="row" id="footer">
			   <div class="col" id="footer_box1">
				   <h1>SSAFY 5TH</h1>
				</div>
			<div class="col" id="footer_box3">
				   <div class="row">
					   <h2>1ST SEMESTER</h2>
				   </div>
				   <div class="row">
					   <h2>FINAL PROJECT</h2>
				   </div>
			   </div>
			   <div class="col" id="footer_box2">
				   <div class="row">
					   <div class="col">
						   <label>MADE BY</label>
					   </div>
					    <div class="col" style="margin-top:100px;">
						    <h2>TEAM LEADER</h2>
				  			 <h2>TEAM MEMBER</h2>
					   </div>
					   <div class="col" style="margin-top:100px;">
						    <h3>RYU SANG OH</h3>
				  			 <h3>CHOI JUN OH</h3>
					   </div>
				   </div>
				   
				   
			   </div>
			   <div class="col" id="footer_box4">
				 <span>ⓒ All Rights Reserved</span>
			   </div>
			   
			  
		   </div>
	   </footer>
    </div>
</template>
<script>
import {mapState,mapActions} from 'vuex';
export default {
  components: {  },
data: function() {
    return {
      login: false,
    };
  },
  computed:{
    ...mapState(['currentnum']),
    },
  methods: {
    ...mapActions(['change_num']),
    logout(){
      this.$session.destroy();
      this.$router.push('/login');
    },
    change(){
      this.change_num(1);
    }
  },
  
  
}
</script>

<style>
#footer{
	
	width:100%;
	height: 300px;
	background-color: rgb(24, 23, 23);
}

#footer_box1 h1{
	margin-top: 100px;
	margin-left: 100px;
	font-size: 70px;
	color: grey;
	font-weight: 1000;
}

#footer_box2 label{
	margin-top: 110px;
	margin-left: -300px;
	font-size: 50px;
	color: grey;
	font-weight: 1000;
}

#footer_box2 h2{

	margin-left: -200px;
	font-size: 35px;
	color: grey;
	font-weight: 1000;
}

#footer_box2 h3{

	margin-left: -100px;
	font-size: 35px;
	color: grey;
	font-weight: 1000;
}

#footer_box3{
	margin-top: 90px;
}

#footer_box3 h2{

	
	margin-left: -100px;
	font-size: 40px;
	color: grey;
	font-weight: 1000;
}

#footer_box4{
	margin-top: 110px;
}

#footer_box4 span{
	margin-left: 100px;
	font-size: 40px;
	color: grey;
	font-weight: 1000;
	
}
</style>
