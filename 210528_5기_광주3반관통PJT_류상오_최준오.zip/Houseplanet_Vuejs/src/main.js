import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import VueSession from "vue-session";
import { mapActions } from "vuex";
import * as VueGoogleMaps from "vue2-google-maps";
import { BootstrapVue } from "bootstrap-vue";

Vue.use(BootstrapVue);
Vue.use(VueSession, { persist: true });

Vue.use(VueGoogleMaps, {
  load: {
    key: "AIzaSyCUxGixwZeVBlQ0SjP3kD4ff-f--81mvv4",
    libraries: "places",
  },
});

import "bootstrap/dist/css/bootstrap.css";
import "bootstrap-vue/dist/bootstrap-vue.css";


Vue.config.productionTip = false;

new Vue({
  router,
  store,
  render: (h) => h(App),
  methods: {
    ...mapActions(["getCityList"]),
  },
  created() {
    this.getCityList();
  },
}).$mount("#app");
