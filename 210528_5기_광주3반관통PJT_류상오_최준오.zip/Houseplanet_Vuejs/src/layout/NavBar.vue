<template>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid text-uppercase">
      <router-link class="navbar-brand" to="/">Happy House</router-link>
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarCollapse"
        aria-controls="navbarCollapse"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <router-link class="nav-link" to="/apt">아파트</router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" v-on:click.native="change" to="/board"
              >게시판</router-link
            >
          </li>
          <li class="nav-item">
            <router-link class="nav-link" v-on:click.native="change" to="/notice"
              >공지사항</router-link
            >
          </li>
          <li class="nav-item">
            <router-link class="nav-link" v-if="!this.$session.exists()" to="/login"
              >로그인</router-link
            >
          </li>
          <li class="nav-item">
            <router-link
              class="nav-link"
              to="/"
              v-if="this.$session.exists()"
              v-on:click.native="logout"
              >로그아웃</router-link
            >
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/register" v-if="!this.$session.exists()"
              >회원가입</router-link
            >
          </li>
        </ul>
      </div>
    </div>
  </nav>
</template>

<script>
export default {};
</script>

<style></style>
