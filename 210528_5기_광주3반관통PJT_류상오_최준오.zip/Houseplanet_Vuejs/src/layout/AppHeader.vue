<template>
  <header>
    <nav-bar></nav-bar>
  </header>
</template>
<script>
import NavBar from "@/layout/NavBar.vue";
export default {
  components: {
    NavBar,
  },
};
</script>
<style></style>
