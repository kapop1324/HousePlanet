<template>
  <div class="container">
      <div class="row" id="login_head">
          <div class="col" id="login_col1">
              <img src="../assets/aaa.png" />
          </div>
          <div class="col" id="login_col2">
            <div class="row" id="login_box1">
                <h1>LOGIN</h1>
            </div>
            <div class="row" id="login_box2">
                <label>ID</label>
                <input 
                    type="text"
                    ref="id"
                    id="id"
                    v-model="id"
                    placeholder="아이디를 입력하세요">
             </div>
            <div class="row" id="login_box3">
                <label>PASSWORD</label>
                <input 
                    type="password"
                    ref="pw"
                    id="pw"
                    v-model="pw"
                    placeholder="패스워드를 입력하세요"
                >
            </div>
            <div class="row" id="login_box4">
                <button class="button"
                @click="login"
                >SUBMIT</button>

            </div>
          </div>
      </div>
      

  </div>
</template>

<script>
import {mapActions} from 'vuex';
export default {
    data: function(){
        return {
            id:'',
            pw:'',
        }
    },
    methods: {
        ...mapActions(['user_login']),
        login(){
            this.user_login({
                id : this.id,
                pw : this.pw,
            });
           
        }
    },
}
</script>

<style>
#login_head{
    margin-top: 200px;
}

#login_head img{
    
    width:600px;
    height: 800px;
}

#login_head h1{
    font-size: 70px;
    font-weight: 1000;
}
#login_head label{
    font-size: 40px;
    font-weight: 1000;
}


#login_col2{
    margin-left: 150px;
    margin-top:50px;
}



#login_box2 {
    margin-top:50px;
}

#login_box2 input{
    margin-top:20px;
    width: 400px;
    height: 80px;
    border-radius: 20px;
    background-color: darkseagreen;
    border:1px solid white;
    color: white;
    font-size: 25px;
    padding-left: 90px ;
}
#login_box2 input::placeholder {
 
    color: white;
    font-size: 20px;
    padding-left: 10px ;

}


#login_box3 {
    margin-top:50px;
}

#login_box3 input{
    margin-top:20px;
    width: 400px;
    height: 80px;
    border-radius: 20px;
    background-color: darkseagreen;
    border:1px solid white;
    color: white;
    font-size: 25px;
    padding-left: 90px ;
}
#login_box3 input::placeholder {
 
    color: white;
    font-size: 20px;
    padding-left: 10px ;

}

#login_box4 {
    margin-top:100px;
}

#login_box4 button{
    margin-left: 100px;
    width: 200px;
    height: 80px;
    border-radius: 50px;
    background-color:dimgray;
    border:1px solid white;
    color: white;
    font-size: 25px;
}

#login_box4 button:hover{

    background-color:gainsboro;
}


</style>