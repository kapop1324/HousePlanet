<template>
<div class="container">
    <div class="row" id="board_formhead">
        <div class="col" id="board_formcol1">
            <div class="row" id="board_formbox1">
                <h1>REVIEW</h1>
            </div>
            <div class="row" id="board_formbox2">
                <div class="row" id="board_formselect">
                    <label>CITY</label>
                        <select @change="city_select" v-model="city">
                            <option v-for="(city_name,index) in citylist" :key="index" :value="city_name.sido_code" >
                                {{city_name.sido_name}}
                            </option>
                        </select>
                </div>
                <div class="row" id="board_formselect">
                    <label>GUNGU</label>
                        <select @change="gugun_select" v-model="gugun">
                            <option v-for="(gugun_name,index) in gugunlist" :key="index" :value="gugun_name.gugun_code">
                                {{gugun_name.gugun_name}}
                            </option>
                        </select>
                </div>
                <div class="row" id="board_formselect">
                        <label>DONG</label>
                        <select v-model="dong">
                            <option v-for="(dong_name,index) in donglist" :key="index" :value="dong_name.dongcode">
                                {{dong_name.dong}}
                            </option>
                        </select>
                </div>
            </div>
                <div class="row" id="board_formbox3">
                    <label>APT NAME</label>
                    <input type="text" v-model="apt_name">
                </div>
                <div class="row" id="board_formbox4">
                    <label>CONTENT</label>
                    <textarea v-model="content"></textarea>
                </div>
                <div class="row" id="board_formbox5">
                    <label id="boxhead">RAING</label>
                    <div>
                        <label id="rate">★★★★★</label>
                        <input type="radio" value = "5" name="rating" v-model="rate">
                        <br>
                        <label id="rate">★★★★</label>
                        <input type="radio" value ="4" name="rating" v-model="rate">
                    <br>
                        <label id="rate">★★★</label>
                        <input type="radio" value="3" name="rating" v-model="rate">
                    <br>
                        <label id="rate">★★</label>
                        <input type="radio" value="2" name="rating" v-model="rate">
                    <br>
                        <label id="rate">★</label>
                        <input  type="radio" value="1" name="rating" v-model="rate">
                    </div>
                </div>
                <div class="row" id="board_formbox6">
                    <button @click="regist_board">등록</button>
                </div>
          </div>
          <div class="col" id="board_formcol2">
              <img src="../assets/orange.jpg">
          </div>
      </div>
      
  </div>
</template>

<script>
import {mapState,mapActions} from 'vuex';
export default {
    
    data() {
        return {
            
            city : "",
            gugun : "",
            dong : "",
            apt_name : "",
            content : "",
            rate : "",
            
        }
    },
    computed:{
     
     ...mapState(['citylist']),
     ...mapState(['gugunlist']),
     ...mapState(['donglist']),

    },
    methods: {
    ...mapActions(['search_gugun']),
    ...mapActions(['search_dong']),
    ...mapActions(['register_board']),
        city_select(){
            
            this.search_gugun(this.city);
        },
        gugun_select(){
            this.search_dong(this.gugun);
        },
        regist_board(){
            
            this.register_board({
            city : this.city,
            gugun : this.gugun,
            dong : this.dong,
            apt_name : this.apt_name,
            content : this.content,
            rate : this.rate,
            id: this.$session.get('user').id,
            })
        },
    
        
    },
    created() {
        this.$store.dispatch('getcity');
        
    },

}
</script>

<style>
    #board_formcol2{
        margin-left: 120px;
    }
    #board_formcol2 img{
        margin-top: 170px;
        width:750px;
        height:1500px;
    }
    #board_formhead{
        margin-top: 150px;
    }

    #board_formbox1 h1{
        font-size: 70px;
        font-weight: 1000;
    }
 
    
    #board_formselect{
        margin-top: 50px;
    }
    #board_formselect label{
        font-size: 30px;
        font-weight: 1000;
    }
    #board_formselect select{
        margin-top: 20px;
        width: 400px;
        height: 70px;
        margin-left: 20px;
        background-color:lightsalmon;
        color: white;
        font-size: 22px;
        padding-left: 30px;
        border-radius: 20px;
        border: 1px solid white;
    }
    #board_formbox3{
        margin-top: 50px;
    }
    #board_formbox3 label{
        font-size: 30px;
        font-weight: 1000;
    }

    #board_formbox3 input{
        margin-top: 20px;
        width: 400px;
        height: 70px;
        margin-left: 20px;
        background-color:lightsalmon;
        color: white;
        font-size: 22px;
        border-radius: 20px;
        padding-left: 30px;
        border: 1px solid white;
    }
    #board_formbox4{
        margin-top: 50px;
    }

    #board_formbox4 label{
        font-size: 30px;
        font-weight: 1000;
    }
    #board_formbox4 textarea{
        margin-top: 20px;
        width: 400px;
        height: 400px;
        margin-left: 20px;
        background-color:lightsalmon;
        color: white;
        font-size: 22px;
        border-radius: 20px;
        padding-top: 10px;
        padding-left: 30px;
        border: 1px solid white;
    }
    #board_formbox5{
        margin-top: 50px;
        
    }

    #board_formbox5 #boxhead{
        font-size: 30px;
        font-weight: 1000;
    }

    #board_formbox5 #rate{
        font-size: 30px;
        font-weight: 1000;
        color:lightsalmon;
        margin-left:50px;
    }

    #board_formbox6{
        margin-top: 100px;
    }
#board_formbox6 button{
    margin-left: 100px;
    width: 200px;
    height: 80px;
    border-radius: 50px;
    background-color:dimgray;
    border:1px solid white;
    color: white;
    font-size: 25px;
}

#board_formbox6 button:hover{

    background-color:gainsboro;
}

    
</style>