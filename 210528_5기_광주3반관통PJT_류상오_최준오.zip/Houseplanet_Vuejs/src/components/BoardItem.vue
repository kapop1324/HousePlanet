<template >
<div>
     <div class="row" id="board_box1">
            <h1>REVIEW</h1>

        </div>
        <div class="container">
        <div class="row" id="board_selectwrap">
                <div class="col" id="board_select1">
                    <label>CITY</label>
                        <select @change="city_select" v-model.lazy="city">
                            <option v-for="(city_name,index) in citylist" :key="index" :value="city_name.sido_code" >
                                {{city_name.sido_name}}
                            </option>
                        </select>
                </div>
                <div class="col"  id="board_select2">
                    <label>GUNGU</label>
                        <select @change="gugun_select" v-model.lazy="gugun">
                            <option v-for="(gugun_name,index) in gugunlist" :key="index" :value="gugun_name.gugun_code">
                                {{gugun_name.gugun_name}}
                            </option>
                        </select>
                </div>
                <div class="col"  id="board_select3">
                        <label>DONG</label>
                        <select v-model.lazy="dong">
                            <option v-for="(dong_name,index) in donglist" :key="index" :value="dong_name.dongcode">
                                {{dong_name.dong}}
                            </option>
                        </select>
                </div>
                <div class="col" id="board_select4">
                    <button class="btn btn-primary" type="button" @click="search_row2">검색</button>
                </div>
            </div>
       <div class="row" id="board_searchwrap"> 
           <div class="col">
               <label>APT NAME</label>
           </div>
           <div class="col" id="board_searchbar">
               <input type="text" v-model.lazy="search_name">
           </div>
           <div class="col" id="board_searchbutton">
            <button type="button" class="btn btn-primary" @click="search_row">검색</button>
           </div>
       </div>
        <div class="row" id="board_box2">
                    <button class="btn btn-secondary" @click="boardregister">등록</button>
                </div>
        <div class="row" id="board_box3">
            <table class="table table-bordered table-hover" style="width:1000px">
                <thead>
                    <tr >
                        <th style="width:10%">No</th>
                        <th style="width:30%">Apt</th>
                        <th style="width:20%">User</th>
                        <th style="width:20%">Rating</th>
                        <th style="width:20%">Date</th>
                    </tr>
                </thead>
                <tbody  v-for="(rev,index) in review_list" :key="index">
                    <tr v-if="search2 == true && city == rev.city && gugun == rev.gugun && dong == rev.dong && search== false && index >= displaypost && index < (displaypost)+postnum">
                        <td>{{index+1}}</td>
                        <td>
                            <router-link :to="`/boarddetail?idx=${rev.idx}`">{{rev.apt_name}}</router-link>
                        </td>
                        <td>{{rev.id}}</td>
                        <td id="rate" v-if="rev.rate == 1">★</td>
                        <td id="rate" v-else-if="rev.rate == 2">★★</td>
                        <td id="rate" v-else-if="rev.rate == 3">★★★</td>
                        <td id="rate" v-else-if="rev.rate == 4">★★★★</td>
                        <td id="rate" v-else-if="rev.rate == 5">★★★★★</td>
                        <td>{{rev.regdate}}</td>
                    </tr>
                    <tr v-if="search2 == false && search== false && index >= displaypost && index < (displaypost)+postnum">
                        <td>{{index+1}}</td>
                        <td>
                            <router-link :to="`/boarddetail?idx=${rev.idx}`">{{rev.apt_name}}</router-link>
                        </td>
                        <td>{{rev.id}}</td>
                        <td id="rate" v-if="rev.rate == 1">★</td>
                        <td id="rate" v-else-if="rev.rate == 2">★★</td>
                        <td id="rate" v-else-if="rev.rate == 3">★★★</td>
                        <td id="rate" v-else-if="rev.rate == 4">★★★★</td>
                        <td id="rate" v-else-if="rev.rate == 5">★★★★★</td>
                        <td>{{rev.regdate}}</td>
                    </tr>
                    <tr v-if="search2 == false && search== true && !rev.apt_name.indexOf(search_name)  && index >= displaypost && index < (displaypost)+postnum">
                        <td>{{index+1}}</td>
                        <td>
                            <router-link :to="`/boarddetail?idx=${rev.idx}`">{{rev.apt_name}}</router-link>
                        </td>
                        <td>{{rev.id}}</td>
                        <td id="rate" v-if="rev.rate == 1">★</td>
                        <td id="rate" v-else-if="rev.rate == 2">★★</td>
                        <td id="rate" v-else-if="rev.rate == 3">★★★</td>
                        <td id="rate" v-else-if="rev.rate == 4">★★★★</td>
                        <td id="rate" v-else-if="rev.rate == 5">★★★★★</td>
                        <td>{{rev.regdate}}</td>
                    </tr>
                </tbody>

            </table>
            </div>
            <div class="row" id="board_box4">
                <div class="col">
                    <div class="pagination" style="margin-left:-10px;">
                   <h1 style="display:none">{{num}}</h1>
                        <span class="page-item">
                         <button class="page-link" style="width:70px;"  v-if="this.startpagenum != 1" @click="prev">prev</button>
                    </span>
                    
                    <span class="page-item" v-for="index in endpagenum" :key="index" >
                        <button class="page-link" v-if="index >= startpagenum && index < startpagenum+pagenum_cnt && index <= pagenum" @click="pagechange(index)">{{index}}</button>
                    </span>
                    <span class="page-item">
                    <button class="page-link" style="width:70px;" v-if="startpagenum != pagenum - (pagenum%pagenum_cnt) +1" @click="next">next</button>

                    </span>

                </div>
                </div>
                
            </div>
               
        
    </div>
    
</div>
    

    
  
</template>

<script>
import {mapState,mapActions} from 'vuex';
export default {
    
    data() {
        return {
            num:"",
            content:"",
            count:"",
            postnum:10,
            pagenum:"",
            displaypost:"",
            pagenum_cnt:10,
            endpagenum:"",
            endpagenum_tmp:"",
            startpagenum:"",
            search_name:"",
            search:false,
            search2:false,
            dong:"",
            city:"",
            gugun:"",
        }
    },
    computed:{
        ...mapState(['review_list','currentnum']),
        ...mapState(['citylist']),
     ...mapState(['gugunlist']),
     ...mapState(['donglist']),
    },
    beforeUpdate() {
        this.num = this.currentnum;
        this.count = this.review_list.length;
        this.pagenum = Math.ceil(this.count/this.postnum);
        this.displaypost = (this.num - 1) * this.postnum;
        this.endpagenum = Math.ceil(this.num / this.pagenum_cnt ) * this.pagenum_cnt;
        this.startpagenum = this.endpagenum - (this.pagenum_cnt - 1);
        if(this.pagenum < 10){
            this.endpagenum = this.pagenum;
        }
       

    },
    methods: {
        search_row(){
            if(this.search_name == ""){
                this.search = false;
            }else{
                this.search = true;
            }
            

        },
        city_select(){
            
            this.search_gugun(this.city);
        },
        gugun_select(){
            this.search_dong(this.gugun);
        },
        search_row2(){
            if(this.dong == "" && this.city == "" && this.gugun == ""){
                this.search2 = false;
            }else{
                this.search2 = true;
            }
            

        },
        ...mapActions(['change_num']),
        ...mapActions(['search_gugun']),
    ...mapActions(['search_dong']),
        boardregister(){
            if(this.$session.exists() == true){
                this.$router.push('/boardregister');
            }else{
                alert("로그인후 작성하실수 있습니다.");
            }
        },
        
        pagechange(index){
            this.num = index;
            this.displaypost = (this.num - 1) * this.postnum;
            this.change_num(this.num);
            
        },
        next(){
           
        this.num = this.endpagenum +1;
        this.change_num(this.num);
     

        },
        prev(){  
        this.num = this.startpagenum -1;
         this.change_num(this.num);

            
        },
        
        
    },
    created() {
        this.$store.dispatch('getcity');
        this.$store.dispatch('getreview');
    },
}
</script>

<style>


#rate{
    color:gold;
}
#board_box1{
    margin: 0px;
    padding: 0px;
    background-image: url('../assets/head1.jpg');
    background-size: cover;
    width:100%;
    height: 300px;
}
#board_box1 h1{
    margin-top: 100px;
    font-size: 80px;
    margin-left: 45%;
    color: white;
}
#board_box2 button{
    width: 100px;
    height: 40px;
    margin-left:900px;
    margin-top:70px;
}
#board_box3{
    margin-top: 20px;
}
#board_box3 a{
    text-decoration: none;
    
}
#board_box3 thead{
    height: 60px;
    background-color:whitesmoke;
    line-height: 30px;
    text-align: center;
}

#board_box3 tbody{
  
    text-align: center;
    font-weight: bold;
   
    
}

#board_box3 tbody tr{
    height: 50px;
    line-height: 50px;
    
}


#board_box3, #board_box2, #board_box4{
    margin-left: 150px;
}
.pagination button{
    width: 50px;
    height: 50px;
}

#board_selectwrap{
    margin-top: 100px;
}

#board_select1 label,#board_select2 label, #board_select3 label{
    font-size: 25px;
    margin-right: 20px;
    font-weight: 1000;
}

#board_select1 select,#board_select2 select, #board_select3 select{
    font-size: 20px;
    width: 150px;
    height: 50px;
    background-color: white;
    color: black;
    font-weight: 1000;
    padding-left: 20px;
    border-radius: 20px;
}

#board_select1{
    margin-left: 210px;;
}
#board_select2{
    margin-left: -40px;;
}

#board_select4 button{
    margin-top: 8px;
    margin-left: 50px;
}

#board_searchwrap{
    margin-top: 50px;
}

#board_searchwrap label{
     font-size: 25px;
   width: 150px;
    font-weight: 1000;
    margin-left: 530px;
    margin-top: 5px;
}

#board_searchbar{
    margin-left: -10px;
}

#board_searchbutton{
    margin-top: 10px;
    margin-left: 65px;
    
}

#board_searchbar input{
    width: 300px;
    height: 50px;
    padding-left: 10px;
    font-size: 20px;
}

</style>