<template>
  <div class="row" id="map_wrap">
    <div class="row" id="map_head">
      <label>MAP</label>
    </div>
    <div class="row" id="map_body">
      <GmapMap
      ref="mapRef"
      :center="mapLoc.center"
      :zoom="mapLoc.zoom"
      @click="hideAptList()"
      style="width: 600px; height: 600px"
    >
      <GmapMarker v-for="(marker, index) in markers" :position="marker" :key="index"> </GmapMarker>
    </GmapMap>
    </div>
    
  </div>
</template>

<script>
import { mapActions } from "vuex";
import { mapState } from "vuex";
export default {
  name: "Map",
  computed: {
    ...mapState(["mapLoc", "markers"]),
  },
  methods: {
    ...mapActions(["moveMap", "hideAptList"]),
  },
  created() {
    this.moveMap();
  },
};
</script>

<style>
#map_wrap{
  margin-left:50px;
}

#map_head{
  margin-top: 100px;
  width: 620px;
  border-bottom: 1px solid black;
}
#map_head label{
  font-size: 50px;
  font-weight: 1000;
  margin-left: -10px;
}

#map_body{
  margin-top: 20px;
 
}

</style>
