<template>
  <div class="container" id="register_wrap">
    <div class="row">
        <div class="col">
       <img src="../assets/aaa.png" />
     </div>
    <div class="col">
      <div class="row" id="register_head">
      <h1>REGIST</h1>
    </div>
    <div class="row" id="register_box1">
      <label for="ID">ID</label>
      <input
        type="text"
        id="id"
        ref="id"
        placeholder="ID를 입력하세요"
        v-model="id"
      />
    </div>
    <div class="row" id="register_box2">
      <label for="pw">PASSWORD</label>
      <input
        type="password"
        class="form-control"
        id="pw"
        ref="pw"
        placeholder="비밀번호를 입력하세요"
        v-model="pw"
      />
    </div>
    <div class="row" id="register_box3">
      <label for="user_name">이름</label>
      <input
        type="text"
        class="form-control"
        id="user_name"
        ref="user_name"
        placeholder="이름을 입력하세요"
        v-model="user_name"
      />
    </div>
    <div class="row" id="register_box4">
      <label for="age">나이</label>
      <input
        type="text"
        class="form-control"
        id="age"
        ref="age"
        placeholder="나이를 입력하세요"
        v-model="age"
      />
    </div>
    <div class="row" id="register_box5">
      <label for="email">이메일</label>
      <input
        type="email"
        class="form-control"
        id="email"
        ref="email"
        placeholder="이메일을 입력하세요"
        v-model="email"
      />
    </div>
    <div class="row" id="register_box6">
      <button
        
        @click="checkhandle"
      >
        등록
      </button>
    </div>
    </div>
   

    </div>
   
    
  </div>
</template>

<script>
import {mapActions,mapState} from 'vuex';
export default {
  name: 'board-Form',
  props: {
    type: { type: String },
  },
  data: function() {
    return {
      id: '',
      pw: '',
      user_name: '',
      age: '',
      email:'',
    };
  },
  computed:{
  },
  methods: {
    ...mapActions(['register']),
    ...mapState(['register_success']),
    checkhandle(){
      let err = true;
      let msg = "";
      !this.id &&((msg = "아이디를 입력해주세요"),(err = false), this.$refs.id.focus());
      err && !this.pw &&((msg = "비밀번호를 입력해주세요"),(err = false), this.$refs.pw.focus());
      err && !this.user_name &&((msg = "이름을 입력해주세요"),(err = false), this.$refs.user_name.focus());
      err && !this.age &&((msg = "나이를 입력해주세요"),(err = false), this.$refs.age.focus());
      err && !this.email &&((msg = "이메일을 입력해주세요"),(err = false), this.$refs.email.focus());

      if(!err) alert(msg);
      else this.check();
    },
    check(){
        this.register({
          id : this.id,
          pw : this.pw,
          user_name : this.user_name,
          age : this.age,
          email : this.email,
        });
    }, 

  },

};
</script>

<style >

#register_wrap{
  margin-top: 200px;
}

#register_wrap label{
    font-size: 40px;
    font-weight: 1000;
}

#register_wrap img{
    
    width:550px;
    height: 1000px;
    margin-top: 150px;
}

#register_head h1{
    font-size: 70px;
    font-weight: 1000;
}

#register_box1, #register_box2, #register_box3
,#register_box4 ,#register_box5,#register_box6 {
    margin-top:50px;
}

#register_box1 input, #register_box2 input, #register_box3 input
,#register_box4 input ,#register_box5 input,#register_box6 input {
     margin-top:20px;
    width: 400px;
    height: 80px;
    border-radius: 20px;
    background-color: darkseagreen;
    border:1px solid white;
    color: white;
    font-size: 25px;
    padding-left: 90px ;
}

#register_box1 input::placeholder , #register_box2 input::placeholder , #register_box3 input::placeholder 
,#register_box4 input::placeholder  ,#register_box5 input::placeholder ,#register_box6 input::placeholder  {
    color: white;
    font-size: 20px;
    padding-left: 10px ;
}



#register_box6 button{
  margin-top: 50px;
  margin-left: 100px;
    width: 200px;
    height: 80px;
    border-radius: 50px;
    background-color:dimgray;
    border:1px solid white;
    color: white;
    font-size: 25px;
}
#register_box6 button:hover{

    background-color:gainsboro;
}

</style>
