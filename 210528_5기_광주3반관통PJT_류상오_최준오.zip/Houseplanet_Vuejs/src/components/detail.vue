<template>
<div>
    <div class="row" id="board_detailbox1"></div>
    <div class="container">
        <div class="row" id="board_detailbox2">
            <div class="row">
                <h1>{{review_detail.apt_name}}</h1> 
            </div>
           <div class="row" style="margin-top:20px; font-size:25px; font-weight:1000; color:darkgray;">
               <div class="col">
                   <span>{{review_detail.cityname}}</span>
               </div>
               <div class="col" style="margin-left:-750px;">
                   <span>{{review_detail.gugunname}}</span>
               </div>
               <div class="col" style="margin-left:-800px;">
                  <span>{{review_detail.dongname}}</span>
               </div>
           </div>
           
           
           
        </div>
        <div class="row" id="board_detailbox3">
            <div class="col" id="board_detailstar">★</div>
            <div class="col" id="board_detailrate">{{review_detail.rate}}.0</div>
        </div>
        <div class="row" id="board_detailbox4">
            <div class="col" id="board_detailbox4_1"> REVIEW</div>
            <div class="col" id="board_detailbox4_2">등록인 : {{review_detail.id}}</div>
                <div class="col" id="board_detailbox4_3">등록일자 : {{review_detail.regdate}}</div>
        </div>
        <div class="row" id="board_detailbox6">
                {{review_detail.content}}
            </div>
        <div class="row" id="board_detailbox5" v-if="review_detail.id == this.$session.get('user').id">
            <div class="col" id="board_detailbox5_1">
                <button class="btn btn-primary" @click="update_detail">수정</button>
            </div>
            <div class="col" id="board_detailbox5_2">
                <button class="btn btn-danger" @click="delete_detail">삭제</button>
            </div>
        </div>
    </div>
</div>
    
</template>

<script>
import {mapState,mapActions} from 'vuex';

export default {
    data() {
        return {
            
        }
    },
    components:{

    },
    computed:{
        ...mapState(['review_detail']),
    },
    methods: {
        ...mapActions(['getreviewdetail','delete_review']),
        delete_detail(){
            if(this.$session.exists() == true && this.$session.get('user').id == this.review_detail.id){
               this.delete_review(this.review_detail.idx);
            
            }else{
                alert("로그인을 먼저 해주십시오");
            }
        },
        update_detail(){
             if(this.$session.exists() == true && this.$session.get('user').id == this.review_detail.id){
               
               this.$router.push("/boardmodify?idx="+this.review_detail.idx);
            
            }else{
                alert("로그인을 먼저 해주십시오");
            }
        },
    },
    created() {
      this.getreviewdetail(this.$route.query.idx);
    },

}
</script>

<style>
#board_detailbox1{
    margin: 0px;
    padding: 0px;
    background-image: url('../assets/head4.jpg');
    background-size: cover;
    width:100%;
    height: 300px;
    
}
#board_detailbox2{
    margin-top: 100px;
    margin-left: 100px;
}
#board_detailbox2 h1{
    font-size: 50px;
    font-weight:1000;
}
#board_detailbox3{
    margin-left: 100px;
}
#board_detailstar{
    font-size: 40px;
    margin-left: 10px;
    color:seagreen;
}
#board_detailrate{
    font-size: 20px;
    font-weight: 600;
    margin-top: 20px;
    margin-left: -1100px;

}
#board_detaildate{
    margin-left: 200px;
    margin-top: 20px;
    font-size: 20px;
}
#board_detailbox4{
    margin-top:30px;
    margin-left: 120px;
}
#board_detailbox4_1{
   font-size: 30px;
   font-weight: 600;
   margin-top: 20px;
}
#board_detailbox4_2{
   font-size: 18px;
   margin-top: 30px;
   margin-right: -400px;
}
#board_detailbox4_3{
   font-size: 18px;
   margin-top: 30px;
   margin-right: -200px;
}
#board_detailbox6{
    margin-top: 20px;
    width: 1000px;
    height: 500px;
    border: 1px solid #e0e0e0;
    border-radius: 10px;
    font-size: 20px;
    padding: 20px;
    overflow: auto;
    margin-left: 120px;
    
}
#board_detailbox5{
    margin-top: 30px;
}
#board_detailbox5_1{
    margin-left: 980px;
}
#board_detailbox5_2{
   margin-left: -220px;
}

</style>