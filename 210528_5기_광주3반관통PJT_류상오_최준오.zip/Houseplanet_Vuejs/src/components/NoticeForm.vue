<template>
  <div class="container">
      <div class="row" id="notice_formwrap">
          <div class="col" id="notice_formcol1">
          <img src="../assets/black.jpg" />
      </div>
      <div class="col" id="notice_formcol2">
          <div class="row" id="notice_formbox1">
              <h1>NOTICE</h1>
          </div>
          <div class="row" id="notice_formbox2">
            <label>TITLE</label>
            <input type="text" v-model="title">
         </div>
          <div  class="row" id="notice_formbox3">
          <label>CONTENT</label>
          <textarea v-model="content"></textarea>
           
         </div> 
          <div  class="row" id="notice_formbox4">
          <button @click="regist_notice">등록</button>
            </div>  
        </div>
      </div>
  </div>
</template>

<script>
import {mapActions} from 'vuex';
export default {
    
    data() {
        return {
            
            title:"",
            content:"",
            
        }
    },
    computed:{

    },
    methods: {
    ...mapActions(['reg_notice']),
    regist_notice(){
            
            this.reg_notice({
                title: this.title,
                content: this.content,
                id : this.$session.get('user').id,
            })
        },
    
        
    },
    
   

}
</script>

<style>
#notice_formwrap{
    margin-top:200px;
}
#notice_formwrap label{
    font-size: 40px;
    font-weight: 1000;
}
#notice_formcol1 img{
    margin-top: 80px;
    width: 600px;
    height: 900px;
}
#notice_formcol2{
    margin-left: 50px;
}

#notice_formbox1 h1{
    font-size: 70px;
    font-weight: 1000;
}

#notice_formbox2{
    margin-top: 50px;
}

#notice_formbox2 input{
    margin-top:20px;
    width: 400px;
    height: 80px;
    border-radius: 20px;
    background-color:darkgray;
    border:1px solid white;
    color: white;
    font-size: 25px;
    padding-left: 30px ;
}

#notice_formbox3{
    margin-top: 50px;
}

#notice_formbox3 textarea{
    margin-top:20px;
    width: 400px;
    height: 400px;
    border-radius: 20px;
    background-color:darkgray;
    border:1px solid white;
    color: white;
    font-size: 25px;
    padding-left: 30px ;
    padding-top:10px;
}

#notice_formbox4 {
    margin-top:100px;
}

#notice_formbox4 button{
    margin-left: 100px;
    width: 200px;
    height: 80px;
    border-radius: 50px;
    background-color:dimgray;
    border:1px solid white;
    color: white;
    font-size: 25px;
}

#notice_formbox4 button:hover{

    background-color:gainsboro;
}


</style>