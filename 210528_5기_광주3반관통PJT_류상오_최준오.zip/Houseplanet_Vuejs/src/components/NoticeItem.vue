<template>
    <div>
        <div class="row" id="notice_box1"> 
          <h1>NOTICE</h1>
      </div>
        <div class=container>
      
      <div class="row" id="notice_box2">
          <button class="btn btn-secondary" @click="reg_notice">등록</button>
      </div>
      <div class="row" id="notice_box3">
          <table  class="table table-bordered table-hover" style="width:1000px">
              <thead>
                  <tr>
                      <th style="width:10%">번호</th>
                      <th style="width:40%">제목</th>
                      <th style="width:20%">작성자</th>
                      <th style="width:30%">등록일</th>
                  </tr>
              </thead>
              <tbody v-for="(notice,index) in notice_list" :key="index">
                  <tr v-if="index >= displaypost && index < (displaypost)+postnum">
                      <td>{{index+1}}</td>
                      <td>
                          <router-link :to="`/noticedetail?idx=${notice.idx}&&num=${num}`">{{notice.title}}</router-link>
                      </td>
                      <td>{{notice.id}}</td>
                      <td>{{notice.regdate}}</td>
                  </tr>
              </tbody>
          </table>
          <div class="row" id="notice_box3">
                <div class="col">
                    <div class="pagination" style="margin-left:-175px;">
                   <h1 style="display:none">{{num}}</h1>
                        <span class="page-item">
                         <button class="page-link" style="width:70px;"  v-if="this.startpagenum != 1" @click="prev">prev</button>
                    </span>
                    
                    <span class="page-item" v-for="index in endpagenum" :key="index" >
                        <button class="page-link" v-if="index >= startpagenum && index < startpagenum+pagenum_cnt && index <= pagenum" @click="pagechange(index)">{{index}}</button>
                    </span>
                    <span class="page-item">
                    <button class="page-link" style="width:70px;" v-if="startpagenum != pagenum - (pagenum%pagenum_cnt) +1" @click="next">next</button>

                    </span>

                </div>
                </div>
        </div>
      </div>
  </div>
    </div>
  
</template>

<script>
import {mapActions,mapState} from 'vuex';
export default {
    data() {
        return {
            num:"",
            content:"",
            count:"",
            postnum:10,
            pagenum:"",
            displaypost:"",
            pagenum_cnt:10,
            endpagenum:"",
            endpagenum_tmp:"",
            startpagenum:"",
        }
    },
    beforeUpdate() {
        this.num = this.currentnum;
        this.count = this.notice_list.length;
        this.pagenum = Math.ceil(this.count/this.postnum);
        this.displaypost = (this.num - 1) * this.postnum;
        this.endpagenum = Math.ceil(this.num / this.pagenum_cnt ) * this.pagenum_cnt;
        this.startpagenum = this.endpagenum - (this.pagenum_cnt - 1);
        this.endpagenum_tmp = Math.ceil(this.count / this.pagenum_cnt);
        // if(this.endpagenum > this.endpagenum_tmp){
        //     this.endpagenum = this.endpagenum_tmp;
        // }
        if(this.pagenum < 10){
            this.endpagenum = this.pagenum;
        }
    },
    methods: {
        ...mapActions(['get_notice','change_num']),
        reg_notice(){
            if(this.$session.get('user').role == 'admin'){
                this.$router.push('/noticeregister');
            }else{
                alert("권한이 없습니다.")
            }
            
        },
         pagechange(index){
            this.num = index;
            this.displaypost = (this.num - 1) * this.postnum;
            this.change_num(this.num);
            
        },
        next(){

        this.num = this.endpagenum +1;
         this.change_num(this.num);
  
        },
        prev(){  
        
        this.num = this.startpagenum -1;
         this.change_num(this.num);
     
            
        }, 
    },
    computed:{
    ...mapState(['notice_list','currentnum']),
    },
    created() {
        this.get_notice();
        console.log(this.currentnum);
        
    },

}
</script>

<style>
#notice_box1{
    margin:0px;
    padding:0px;
    background-image: url('../assets/head2.jpg');
    background-size: cover;
    width:100%;
    height: 300px;
}
#notice_box1 h1{
    margin-top: 100px;
    font-size: 80px;
    
    margin-left: 45%;
    color: white;
}
#notice_box2 button{
    width: 100px;
    height: 40px;
    margin-left:900px;
    margin-top:70px;
}
#notice_box3{
    margin-top: 20px;
}
#notice_box3 a{
    text-decoration: none;
    
}
#notice_box3 thead{
    height: 60px;
    background-color:whitesmoke;
    line-height: 30px;
    text-align: center;
}

#notice_box3 tbody{
  
    text-align: center;
    font-weight: bold;
   
    
}

#notice_box3 tbody tr{
    height: 50px;
    line-height: 50px;
    
}

#notice_box4{
    
}
#notice_box2, #notice_box3, #notice_box4{
    margin-left: 150px;
}
.pagination button{
    width: 50px;
    height: 50px;
}
</style>