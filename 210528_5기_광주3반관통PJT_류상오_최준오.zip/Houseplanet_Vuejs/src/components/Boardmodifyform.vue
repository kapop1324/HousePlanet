<template>
  <div class="container">
      <div class="row" id="board_modifywrap">
        <div class="col" id="board_modifycol1">
            <div class="row" id="board_modifybox1">
          <h1>REVIEW UPDATE</h1>
        </div>
        <div class="row" id="board_modifybox2">
            <label>CONTENT</label>
        <textarea v-model="content"></textarea>
        </div>
        <div class="row" id="board_modifybox3">
            <button @click="modify">update</button>
        </div>
        </div>
        <div class="col" id="board_modifycol2">
            <img src="../assets/orange.jpg">
        </div>
      </div>
  </div>
</template>

<script>
import {mapActions} from 'vuex';
export default {
    data() {
        return {
            content:"",
        }
    },methods: {
        ...mapActions(['modify_review']),
        modify(){
            this.modify_review({
                content:this.content,
                idx : this.$route.query.idx,
            });
        }
        
    },

}
</script>

<style>
    #board_modifycol2 {
        margin-top: 100px;
    }
    #board_modifycol2 img{
        width:600px;
        height: 800px;
    }
    #board_modifywrap{
        margin-top: 200px;
    }
    #board_modifybox1 h1{
        font-size: 60px;
        font-weight: 1000;
    }
    #board_modifybox2{
        margin-top: 50px;
    }
    #board_modifybox2 label{
        font-size: 30px;
        font-weight: 1000;
    }
     #board_modifybox2 textarea{
        margin-top: 20px;
        width: 400px;
        height: 400px;
        margin-left: 20px;
        background-color:lightsalmon;
        color: white;
        font-size: 22px;
        border-radius: 20px;
        padding-top: 10px;
        padding-left: 30px;
        border: 1px solid white;
    }
    #board_modifybox3{
        margin-top: 100px;
    }
    #board_modifybox3 button{
    margin-left: 120px;
    width: 200px;
    height: 80px;
    border-radius: 50px;
    background-color:dimgray;
    border:1px solid white;
    color: white;
    font-size: 25px;
}

#board_modifybox3 button:hover{

    background-color:gainsboro;
}

</style>