<template>
  <div class="container">
      <div class="row" id="notice_modifywrap">
          <div class="col" id="notice_modifycol1">
              <img src="../assets/black2.png" />
          </div>
          <div class="col" id="notice_modifycol2">
            <div class="row" id="notice_modifybox1">
                <h1>NOTICE UPDATE</h1>
            </div>
            <div class="row" id="notice_modifybox2">
                 <label>TITLE</label>
            <input type="text" v-model="title">
            </div>
            <div class="row" id="notice_modifybox3">
                <label>CONTENT</label>
                <textarea v-model="content"></textarea>
            </div>
            <div class="row" id="notice_modifybox4">
                <button @click="modify">수정</button>
            </div>
          </div>
      </div>
      

  </div>
</template>

<script>
import {mapActions} from 'vuex';
export default {
    data() {
        return {
            title:"",
            content:"",
        }
    },methods: {
        ...mapActions(['modify_notice']),
        modify(){
            this.modify_notice({
                title: this.title,
                content:this.content,
                idx : this.$route.query.idx,
            });
        }
        
    },

}
</script>

<style>

#notice_modifywrap{
    margin-top:200px;
}
#notice_modifywrap label{
    font-size: 40px;
    font-weight: 1000;
}

#notice_modifycol1 img{
    margin-top: 90px;
    width: 600px;
    height: 900px;
}

#notice_modifycol2{
    margin-left: 50px;
}

#notice_modifybox1 h1{
    font-size: 70px;
    font-weight: 1000;
}

#notice_modifybox2{
    margin-top: 50px;
}

#notice_modifybox2 input{
    margin-top:20px;
    width: 400px;
    height: 80px;
    border-radius: 20px;
    background-color:darkgray;
    border:1px solid white;
    color: white;
    font-size: 25px;
    padding-left: 30px ;
    margin-left: 30px;
}

#notice_modifybox3{
    margin-top: 50px;
}


#notice_modifybox3 textarea{
    margin-top:20px;
    width: 400px;
    height: 400px;
    border-radius: 20px;
    background-color:darkgray;
    border:1px solid white;
    color: white;
    font-size: 25px;
    padding-left: 30px ;
    padding-top:10px;
    margin-left: 30px;
}

#notice_modifybox4 {
    margin-top:100px;
}

#notice_modifybox4 button{
    margin-left: 130px;
    width: 200px;
    height: 80px;
    border-radius: 50px;
    background-color:dimgray;
    border:1px solid white;
    color: white;
    font-size: 25px;
}

#notice_modifybox4 button:hover{

    background-color:gainsboro;
}


</style>