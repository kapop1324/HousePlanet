<template>
     <div>
         <div class="row" id="notice_detailbox1"></div>
         <div class="container">
             
             <div class="row" id="notice_detailbox2">
                 {{notice_detail.title}}
             </div>
             <div class="row" id="notice_detailbox3">
                 <div class="col" id="notice_detailbox3_1">
                     작성자 : {{notice_detail.id}}
                 </div>
                 <div class="col" id="notice_detailbox3_2">
                     등록일자 : {{notice_detail.regdate}}
                 </div>
             </div>
             <div class="row" id="notice_detailbox4">
                {{notice_detail.content}}
             </div>
            <div class="row" id="notice_detailbox5" v-if="this.$session.get('user').role == 'admin'">
                <div class="col" id="notice_detailbox5_1">
                    <button class="btn btn-primary" @click="update_detail">수정</button>
                </div>
                <div class="col" id="notice_detailbox5_2">
                    <button class="btn btn-danger" @click="delete_detail">삭제</button> 
                </div>
            </div>
         </div>
      
    </div>
</template>

<script>
import {mapState,mapActions} from 'vuex';
export default {
    
    data() {
        return {
            
        }
    },
    components:{
        

    },
    computed:{
    ...mapState(['notice_detail']),
    },
    methods: {
        ...mapActions(['search_notice','delete_notice','change_num']),

         delete_detail(){
            if(this.$session.exists() == true){
                if(this.$session.get('user').role == 'admin'){
                    this.delete_notice(this.notice_detail.idx);
                }else{
                    alert("권한이 없습니다.");
                }
            }else{
                alert("로그인을 먼저 해주십시오");
            }
        },
        update_detail(){

            if(this.$session.exists() == true){
                if(this.$session.get('user').role == 'admin'){
                    this.$router.push("/noticemodify?idx="+this.notice_detail.idx);
                }else{
                    alert("권한이 없습니다.");
                }
            }else{
                alert("로그인을 먼저 해주십시오");
            }

        },
        
    },
    created() {

        this.search_notice(this.$route.query.idx);
        this.change_num(this.$route.query.num);
        console.log(this.currentnum);
    },
}
</script>

<style>
    #notice_detailbox1{
    margin: 0px;
    padding: 0px;
    background-image: url('../assets/head3.jpg');
    background-size: cover;
    width:100%;
    height: 300px;
}
    #notice_detailbox2{
        margin-top: 100px;
        font-size: 40px;
        font-weight: 1000;
        margin-left: 100px;
    }
    #notice_detailbox3{
        margin-top: 50px;
        font-size: 20px;
    }
    #notice_detailbox3_1{
        margin-left: 850px;
    }
     #notice_detailbox3_2{
         margin-left: 0px;
    }
    #notice_detailbox4{
          margin-top: 20px;
    width: 1200px;
    height: 500px;
    border: 1px solid #e0e0e0;
    border-radius: 10px;
    font-size: 25px;
    padding: 30px;
    overflow: auto;
    margin-left: 100px
    
    }
    #notice_detailbox5{
        margin-top:30px
    }
    #notice_detailbox5_1{
        margin-left: 1160px;
    }
    #notice_detailbox5_2{
        margin-left: -10px;
    }
</style>