<template>
  <div class="row" id="apt_listwrap">
    <div class="row" id="apt_listhead">
      <label>APT LIST</label>
    </div>
    <div class="row" id="apt_listbody">
      <table class="table-border">
        <thead head-variant="success">
          <th>일련번호</th>
          <th>아파트명</th>
          <th>건축년도</th>
        </thead>
        <tbody>
          <apt-item v-for="(apt, index) in filteredApts" :key="index + 'i'" :apt="apt"></apt-item>
        </tbody>
        
      </table>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
import AptItem from "@/components/apt/AptItem.vue";
export default {
  computed: {
    ...mapState(["filteredApts", "apt"]),
  },
  components: {
    AptItem,
  },
};
</script>

<style>
#apt_listwrap {
  margin-left: 0px;
}
#apt_listhead {
  margin-top: 100px;
  width: 620px;
  border-bottom: 1px solid black;
}

#apt_listhead label {
  font-size: 50px;
  font-weight: 1000;
  margin-left: -10px;
}
</style>
