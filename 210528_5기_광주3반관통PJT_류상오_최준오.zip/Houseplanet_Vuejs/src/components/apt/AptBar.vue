<script>
import { Bar } from "vue-chartjs";

export default {
  extends: Bar,
  props: ["apt"],
  methods: {
    update() {
      let names = [];
      let prices = [];
      for (let i = 0; i < this.apt.length; i++) {
        names.push(this.apt[i].년 + "." + this.apt[i].월 + "." + this.apt[i].일);
        prices.push(parseInt(this.apt[i].거래금액.replace(",", "")));
      }
      console.log(prices);
      this.renderChart({
        labels: names,
        datasets: [
          {
            // label: "Data One",
            backgroundColor: "#f87979",
            pointBackgroundColor: "white",
            borderWidth: 1,
            pointBorderColor: "#249EBF",
            data: prices,
          },
        ],
      });
    },
  },
//   watch: {
//     apt: functions(){
//       let names = [];
//       let prices = [];
//       for (let i = 0; i < this.apt.length; i++) {
//         names.push(this.apt[i].년 + "." + this.apt[i].월 + "." + this.apt[i].일);
//         prices.push(parseInt(this.apt[i].거래금액.replace(",", "")));
//       }
//       console.log(prices);
//       this.renderChart({
//         labels: names,
//         datasets: [
//           {
//             // label: "Data One",
//             backgroundColor: "#f87979",
//             pointBackgroundColor: "white",
//             borderWidth: 1,
//             pointBorderColor: "#249EBF",
//             data: prices,
//           },
//         ],
//       });
//     },
//   },
  mounted() {
    this.update();
  },
};
</script>
