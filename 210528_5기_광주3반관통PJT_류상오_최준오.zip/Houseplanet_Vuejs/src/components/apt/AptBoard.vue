<template>
  <div class="row" id="apt_board_wrap" v-if="getReviews.length > 0">
    <div class="row" id="apt_board_head">
      <label>평점: {{ avgStar }}</label>
    </div>
    <table class="table table-bordered table-hover mt-3" style="width: 1000px">
      <thead>
        <tr>
          <th style="width: 10%">No</th>
          <th style="width: 30%">Apt</th>
          <th style="width: 20%">User</th>
          <th style="width: 20%">Rating</th>
          <th style="width: 20%">Date</th>
        </tr>
      </thead>
      <tbody  >
        <tr v-for="(rev, index) in getReviews" :key="index">
          <td  v-if="index < 5">{{ index + 1 }}</td>
          <td  v-if="index < 5">
            <router-link :to="`/boarddetail?idx=${rev.idx}`">{{ rev.apt_name }}</router-link>
          </td>
          <td  v-if="index < 5 && index < 5">{{ rev.id }}</td>
          <td  id="rate" v-if="rev.rate == 1 && index < 5">★</td>
          <td id="rate" v-else-if="rev.rate == 2 && index < 5">★★</td>
          <td id="rate" v-else-if="rev.rate == 3 && index < 5">★★★</td>
          <td id="rate" v-else-if="rev.rate == 4 && index < 5">★★★★</td>
          <td id="rate" v-else-if="rev.rate == 5 && index < 5">★★★★★</td>
          <td v-if="index < 5">{{ rev.regdate }}</td>
        </tr>
      </tbody>
    </table>
    <!-- <table class="table mt-3 table-bordered table-striped table-hover">
      <thead>
        <th>번호</th>
        <th>내용</th>
        <th>작성자</th>
        <th>작성일</th>
      </thead>

      <tr v-for="(item, index) in getReviews" :key="index">
        <td>{{ item.idx }}</td>
        <td>
          <a href="" @click.prevent="moveToReview(item.idx)">{{ item.content }}</a>
        </td>
        <td>{{ item.id }}</td>
        <td>{{ item.regdate }}</td>
      </tr>
    </table> -->
  </div>
</template>

<script>
import { mapGetters, mapState } from "vuex";
export default {
  data() {
    return {
      avgStar: 0,
    };
  },
  computed: {
    ...mapGetters(["getReviews"]),
    ...mapState(["apt"]),
    
  },
  methods: {
    updateStar() {
      let sum = 0;
      for (let i = 0; i < this.getReviews.length; i++) {
        sum += this.getReviews[i].rate;
      }
      this.avgStar = sum / this.getReviews.length;
    },
    moveToReview(idx) {
      this.$router.push({ name: "boarddetail", query: { idx: idx } });
    },
  },
  watch: {
    getReviews: function () {
      this.updateStar();
      this.avgStar = Math.floor(this.avgStar * 10) / 10;
      
    },
  },
  created() {
    this.updateStar();
    this.avgStar = Math.floor(this.avgStar * 10) / 10;
  },
};
</script>

<style>
#apt_board_wrap {
  margin-left: 50px;
}
#apt_board_head {
  margin-top: 50px;
  width: 1020px;
  border-bottom: 1px solid black;
}

#apt_board_head label {
  font-size: 50px;
  font-weight: 1000;
  margin-left: -10px;
}
</style>
