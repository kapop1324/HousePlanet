<script>
import { Bar } from "vue-chartjs";
import { mapState } from "vuex";
export default {
  extends: Bar,
  computed: {
    ...mapState(["apts"]),
  },
  methods: {
    update() {
      let names = [];
      let avgList = [];
      for (let i = 0; i < this.apts.length; i++) {
        let sum = 0;
        names.push(this.apts[i][0].아파트);
        for (let j = 0; j < this.apts[i].length; j++) {
          sum += parseInt(this.apts[i][j].거래금액.replace(",", ""));
        }
        avgList.push(sum / this.apts[i].length);
      }
      this.renderChart({
        labels: names,
        datasets: [
          {
            label: "아파트별 평균 거래가격",
            backgroundColor: "#f87979",
            pointBackgroundColor: "white",
            borderWidth: 1,
            pointBorderColor: "#249EBF",
            data: avgList,
          },
        ],
      });
    },
  },
  watch: {
    apts() {
      this.update();
    },
  },
  mounted() {
    this.update();
  },
};
</script>
