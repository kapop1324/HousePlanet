<template>
  <b-tr >
    <b-td>{{ apt[0].일련번호 }}</b-td>
    <b-td @click="showAptDetail(apt)">{{ apt[0].아파트 }}</b-td>
    <b-td>{{ apt[0].건축년도 }}</b-td>
  </b-tr>
</template>

<script>
import { mapActions } from "vuex";
export default {
  props: {
    apt: Array,
  },
  methods: {
    ...mapActions(["showAptDetail"]),
  },
};
</script>

<style></style>
