<template>
  <div class="row">
    <div class="row" id="aptsearch_box1">
      <h1>APT SEARCH</h1>
    </div>
    <div class="row" id="aptsearch_box2">
      <label>CITY</label>
      <b-form-select name="city" id="" v-model="city" @change="checkGugun(city)">
        <b-form-select-option value="" disabled>도시를 선택하세요</b-form-select-option>
        <b-form-select-option v-for="(item, index) in cities" :key="index" :value="item.code">
          {{ item.city }}
        </b-form-select-option>
      </b-form-select>
    </div>
    <div class="row" id="aptsearch_box3">
      <label>GUGUN</label>
      <b-form-select name="gugun" id="" v-model="gugun" @change="checkDong(gugun)">
        <b-form-select-option value="" disabled>군/구를 선택하세요</b-form-select-option>
        <b-form-select-option v-for="(item, index) in guguns" :key="index" :value="item.code">
          {{ item.gugun }}
        </b-form-select-option>
      </b-form-select>
    </div>
    <div class="row" id="aptsearch_box4">
      <label>DONG</label>
      <b-form-select name="dong" id="" v-model="dong" @change="checkAptByDong(dong)">
        <b-form-select-option value="" disabled>동을 선택하세요</b-form-select-option>
        <b-form-select-option v-for="(item, index) in dongs" :key="index" :value="item.code">
          {{ item.dong }}
        </b-form-select-option>
      </b-form-select>
    </div>
    <div class="row" id="aptsearch_box5">
      <div class="col"><label>FILTER</label></div>
      <div class="col">
        <b-button v-if="!showFilter" @click="clickFilter()">+</b-button>
        <b-button v-if="showFilter" @click="clickFilter()">-</b-button>
      </div>
    </div>
  </div>
</template>

<script>
import { mapActions } from "vuex";
import { mapState } from "vuex";
export default {
  data() {
    return {
      city: "",
      gugun: "",
      dong: "",
      dongCode: "",
    };
  },
  components: {},
  computed: {
    ...mapState(["cities", "guguns", "dongs", "showFilter", "showList"]),
  },
  methods: {
    ...mapActions([
      "getAptListByDong",
      "getAptListByGugun",
      "getGugunList",
      "getDongList",
      "clickFilter",
      "moveMap",
      "showAptList",
    ]),

    checkGugun(cityCode) {
      this.gugun = "";
      this.dong = "";
      this.getGugunList(cityCode);
    },
    checkDong(gugunCode) {
      this.dong = "";
      this.getDongList(gugunCode);
      this.checkAptByGugun(gugunCode);
    },
    checkAptByDong(dongCode) {
      let loc = "";
      for (let i = 0; i < this.cities.length; i++) {
        console.log(this.cities[i].code);
        if (this.cities[i].code == this.city) {
          loc += this.cities[i].city;
          console.log(1);
          break;
        }
      }
      for (let i = 0; i < this.guguns.length; i++) {
        if (this.guguns[i].code == this.gugun) {
          loc += " " + this.guguns[i].gugun;
          break;
        }
      }
      for (let i = 0; i < this.dongs.length; i++) {
        if (this.dongs[i].code == this.dong) {
          loc += " " + this.dongs[i].dong;
          break;
        }
      }
      this.moveMap(loc);
      this.getAptListByDong(dongCode);
      if (!this.showList) {
        this.showAptList();
      }
    },
    checkAptByGugun(gugunCode) {
      let loc = "";
      for (let i = 0; i < this.cities.length; i++) {
        console.log(this.cities[i].code);
        if (this.cities[i].code == this.city) {
          loc += this.cities[i].city;
          console.log(1);
          break;
        }
      }
      for (let i = 0; i < this.guguns.length; i++) {
        if (this.guguns[i].code == this.gugun) {
          loc += " " + this.guguns[i].gugun;
          break;
        }
      }
      this.moveMap(loc);
      this.getAptListByGugun(gugunCode);
      if (!this.showList) {
        this.showAptList();
      }
    },
  },
};
</script>

<style>
#aptsearch_box1 {
  margin-top: 100px;
}

#aptsearch_box1 h1 {
  font-size: 60px;
  font-weight: 1000;
  color: white;
  margin-left: 200px;
}
#aptsearch_box2 {
  margin-top: 100px;
}

#aptsearch_box2 label,
#aptsearch_box3 label,
#aptsearch_box4 label,
#aptsearch_box5 label {
  font-size: 40px;
  font-weight: 1000;
  color: white;
  margin-left: 200px;
}
#aptsearch_box2 select,
#aptsearch_box3 select,
#aptsearch_box4 select {
  margin-top: 10px;
  width: 500px;
  height: 50px;
  font-size: 25px;
  margin-left: 210px;
  border-radius: 10px;
  border: 1px solid white;
}

#aptsearch_box3,
#aptsearch_box4,
#aptsearch_box5 {
  margin-top: 50px;
}
#aptsearch_box5 button {
  margin-top: -18px;
  margin-left: -80px;
  background-color: transparent;
  border: none;
  box-shadow: none;
  font-size: 50px;
  font-weight: 1000;
}
#aptsearch_box6 {
  margin-top: 550px;
}

#aptsearch_box6 button {
  width: 250px;
  height: 70px;
  border-radius: 20px;
  font-size: 30px;
  font-weight: 1000;
  margin-left: 300px;
}
</style>
