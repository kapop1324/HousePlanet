<template>
  <div>
    <div class="container" id="filter_wrap">
      <div class="row">
        <div class="col" id="filter_col1">
          <div class="row">
            <b-form-group style="color:white; font-size:30px; font-weight:500; margin-left:20px;" label="평수" v-slot="{ ariaDescribedby }">
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value=""
            v-model="filter.size"
            >전체</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="0"
            v-model="filter.size"
            >10평 이하</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="1"
            v-model="filter.size"
            >10평대</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="2"
            v-model="filter.size"
            >20평대</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="3"
            v-model="filter.size"
            >30평대</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="4"
            v-model="filter.size"
            >40평대</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="5"
            v-model="filter.size"
            >50평대</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="6"
            v-model="filter.size"
            >60평 이상</b-form-radio
          >
        </b-form-group>
          </div>
        </div>
        <div class="col" id="filter_col2">
          <div class="row">
             <b-form-group style="color:white; font-size:30px; font-weight:500; margin-left:0px;" label="시공년도" v-slot="{ ariaDescribedby }">
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value=""
            v-model="filter.completedDate"
            >전체</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="5"
            v-model="filter.completedDate"
            >5년 이내</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="10"
            v-model="filter.completedDate"
            >10년 이내</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="15"
            v-model="filter.completedDate"
            >15년 이내</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="29"
            v-model="filter.completedDate"
            >20년 이내</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="25"
            v-model="filter.completedDate"
            >25년 이내</b-form-radio
          >
        </b-form-group>
          </div>
        </div>
        <div class="col" id="filter_col3">
          <div class="row">
               <b-form-group style="color:white; font-size:30px; font-weight:500; margin-left:0px;" label="시세" v-slot="{ ariaDescribedby }">
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value=""
            v-model="filter.price"
            >전체</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="1"
            v-model="filter.price"
            >1억 미만</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="2"
            v-model="filter.price"
            >2억 미만</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="5"
            v-model="filter.price"
            >5억 미만</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="10"
            v-model="filter.price"
            >10억 미만</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="20"
            v-model="filter.price"
            >20억 미만</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="30"
            v-model="filter.price"
            >30억 미만</b-form-radio
          >
          <b-form-radio
            type="radio"
            :aria-describedby="ariaDescribedby"
            value="300"
            v-model="filter.price"
            >30억 이상</b-form-radio
          >
        </b-form-group>
          </div>
        </div>
      </div>
      <div class="row" id="filter_button">
        <b-button ml="3" @click="chk()">적용</b-button>
      </div>
    </div>
  </div>
 
</template>

<script>
import { mapActions } from "vuex";
export default {
  name: "AptFilter",
  data() {
    return {
      filter: {
        size: "",
        price: "",
        completedDate: "",
      },
    };
  },
  methods: {
    ...mapActions(["setFilter"]),
    chk() {
      this.setFilter(this.filter);
    },
  },
};
</script>

<style>
  #filter_wrap{
    margin-top: 20px;
    border-top: 3px solid white;
    padding-top: 20px;
  }
  #filter_col1 label, #filter_col2 label, #filter_col3 label{
    color: white;
    font-size: 20px;
    font-weight: 500px;
    margin-left: 10px;
  }
  #filter_col1{
    margin-left: 100px;
  }
  #filter_button{
    margin-top:-510px;
    margin-left: 360px;
  }
  #filter_button button{
    width:100px;
    height: 50px;
    font-size: 20px;
    background-color: transparent;
    border:none;
    box-shadow: none;
    font-weight: 1000;
    margin-top: -5px;
  }
</style>
