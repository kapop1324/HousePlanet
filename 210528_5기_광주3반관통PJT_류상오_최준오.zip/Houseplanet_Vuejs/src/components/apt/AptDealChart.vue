<script>
import { Pie } from "vue-chartjs";
import { mapState } from "vuex";
export default {
  extends: Pie,
  computed: {
    ...mapState(["apts"]),
  },
  methods: {
    update() {
      let names = [];
      let dealList = [];
      let bgColorList = [];
      for (let i = 0; i < this.apts.length; i++) {
        names.push(this.apts[i][0].아파트);
        dealList.push(this.apts[i].length);
        bgColorList.push("#" + Math.floor(Math.random() * 16777215).toString(16));
      }
      console.log(bgColorList);
      this.renderChart({
        labels: names,
        datasets: [
          {
            label: "아파트별 거래량",
            backgroundColor: bgColorList,
            pointBackgroundColor: "white",
            borderWidth: 1,
            pointBorderColor: "#249EBF",
            data: dealList,
          },
        ],
      });
    },
  },
  watch: {
    apts() {
      this.update();
    },
  },
  mounted() {
    this.update();
  },
};
</script>
