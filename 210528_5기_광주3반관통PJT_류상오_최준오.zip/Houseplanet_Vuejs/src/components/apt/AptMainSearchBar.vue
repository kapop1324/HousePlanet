<template>
  <div class="select_box">
    <select
      class="form-select form-select-lg"
      aria-label="Default select example"
      style="width: 250px"
      name="city"
      id=""
      v-model="city"
      @change="checkGugun(city)"
    >
      <option value="" disabled>도시를 선택하세요</option>
      <option v-for="(item, index) in cities" :key="index" :value="item.code">
        {{ item.city }}
      </option>
    </select>

    <select
      class="form-select form-select-lg"
      aria-label="Default select example"
      style="width: 250px"
      name="gugun"
      id=""
      v-model="gugun"
      @change="checkDong(gugun)"
    >
      <option value="" disabled>군/구를 선택하세요</option>
      <option v-for="(item, index) in guguns" :key="index" :value="item.code">
        {{ item.gugun }}
      </option>
    </select>

    <select
      class="form-select form-select-lg"
      aria-label="Default select example"
      style="width: 250px"
      name="dong"
      id=""
      v-model="dong"
    >
      <option value="" disabled>동을 선택하세요</option>
      <option v-for="(item, index) in dongs" :key="index" :value="item.code">
        {{ item.dong }}
      </option>
    </select>

    <button
      type="button"
      class="btn btn-secondary"
      name="gugun-search"
      @click="checkAptByDong(dong)"
      style="height: 50px; font-size: 18px"
    >
      검색
    </button>
    <!-- <input type="text" v-model="dongCode" @keydown.enter="getAptList(dongCode)" />
    <button @click="getAptList(dongCode)">검색</button> -->
  </div>
</template>

<script>
import { mapActions } from "vuex";
import { mapState } from "vuex";
export default {
  data() {
    return {
      city: "",
      gugun: "",
      dong: "",
      dongCode: "",
    };
  },
  components: {},
  computed: {
    ...mapState(["cities", "guguns", "dongs", "showList"]),
  },
  methods: {
    ...mapActions(["getAptListByDong", "getGugunList", "getDongList", "moveMap", "showAptList"]),

    checkGugun(cityCode) {
      this.gugun = "";
      this.dong = "";
      this.getGugunList(cityCode);
    },
    checkDong(gugunCode) {
      this.dong = "";
      this.getDongList(gugunCode);
    },
    checkAptByDong(dongCode) {
      let loc = "";
      if (dongCode == "") {
        alert("동을 선택하세요");
        return;
      }
      for (let i = 0; i < this.cities.length; i++) {
        console.log(this.cities[i].code);
        if (this.cities[i].code == this.city) {
          loc += this.cities[i].city;
          console.log(1);
          break;
        }
      }
      for (let i = 0; i < this.guguns.length; i++) {
        if (this.guguns[i].code == this.gugun) {
          loc += " " + this.guguns[i].gugun;
          break;
        }
      }
      for (let i = 0; i < this.dongs.length; i++) {
        if (this.dongs[i].code == this.dong) {
          loc += " " + this.dongs[i].dong;
          break;
        }
      }
      this.moveMap(loc);
      this.getAptListByDong(dongCode);
      if (!this.showList) {
        this.showAptList();
      }
      this.$router.push("/apt");
    },
  },
};
</script>

<style>
.select_box {
  display: flex;
  justify-content: center;
  align-items: center;
}
.select_box > select {
  margin-right: 20px;
}
</style>
