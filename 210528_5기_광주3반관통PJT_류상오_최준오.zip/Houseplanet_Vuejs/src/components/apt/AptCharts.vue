<template>
  <div class="row mt-5">
    <div class="col">
      <apt-deal-chart></apt-deal-chart>
    </div>
    <div class="col">
      <apt-avg-chart></apt-avg-chart>
    </div>
    <div class="col">
      <apt-detail-chart></apt-detail-chart>
    </div>
  </div>
</template>

<script>
import AptDealChart from "@/components/apt/AptDealChart.vue";
import AptDetailChart from "@/components/apt/AptDetailChart.vue";
import AptAvgChart from "@/components/apt/AptAvgChart.vue";

export default {
  components: {
    AptDealChart,
    AptDetailChart,
    AptAvgChart,
  },
};
</script>

<style></style>
