<script>
import { Line } from "vue-chartjs";
import { mapState } from "vuex";
export default {
  extends: Line,
  computed: {
    ...mapState(["apt"]),
  },
  methods: {
    update() {
      let names = [];
      let prices = [];
      for (let i = 0; i < this.apt.length; i++) {
        names.push(this.apt[i].년 + "." + this.apt[i].월 + "." + this.apt[i].일);
        prices.push(parseInt(this.apt[i].거래금액.replace(",", "")));
      }
      console.log(prices);
      this.renderChart({
        labels: names,
        datasets: [
          {
            label: "가격 변동 추이",
            backgroundColor: "#f87979",
            pointBackgroundColor: "white",
            borderWidth: 2,
            borderColor: "#de0082",
            pointBorderColor: "red",
            data: prices,
            fill: false,
          },
        ],
      });
    },
  },
  watch: {
    apt() {
      this.update();
    },
  },
  mounted() {
    this.update();
  },
};
</script>
