<template>
  <div class="row" id="detail_wrap">
    <div class="row" id="detail_head">
      <div class="row">
        <label>DETAIL</label>
      </div>
      <div class="row">
        <label>({{ apt[0].아파트 }})</label>
      </div>
      
    </div>
    <table class="table table-bordered table-hover mt-3">
      <thead>
        <th>거래일자</th>
        <th>실거래가</th>
        <th>층</th>
        <th>전용면적</th>
      </thead>
    <tbody >
      <tr  v-for="(item, index) in apt" :key="index">
        <td>{{ item.년 }}.{{ item.월 }}.{{ item.일 }}</td>
        <td>{{ (item.거래금액.replace(",", "") * 10000) | price }}원</td>
        <td>{{ item.층 }}</td>
        <td>{{ item.전용면적 }}m^2</td>
      </tr>
    </tbody>
    </table>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  name: "AptDetail",
  props: { apt: Array },
  computed: {
    ...mapGetters(["getReviews"]),
  },
  filters: {
    price(value) {
      if (!value) return value;
      return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    },
  },
};
</script>

<style>
#detail_wrap {
  margin-left: 0px;
}
#detail_head {
  margin-top: 100px;
  width: 700px;
  border-bottom: 1px solid black;
}

#detail_head label {
  font-size: 50px;
  font-weight: 1000;
  margin-left: -10px;
}
</style>
