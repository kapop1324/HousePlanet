<template>
    <div class="container" id="comment_wrap">
        <div class="row" id="comment_box1">
            <div class="row">
                    <label>COMMENT</label>
            </div>
            <div class="row">
                <div class="col">
                    <textarea v-model="content"></textarea>
                </div>
                 <div class="col" >
           
             </div>

        </div>
       <div class="row" id="comment_box1_1">
            <button class="btn btn-secondary" @click="commentreg">등록</button>
       </div>
        </div>
        <div class="row" id="comment_box2">
            <table class="table table-bordered table-hover" style="width:1000px">
                <thead>
                    <tr>
                        <th style="width:20%">아이디</th>
                        <th style="width:60%">내용</th>
                        <th style="width:20%">등록일</th>
                    </tr>

                </thead>
                <tbody v-for="(cmt, index) in comment_list" :key="index" >
                    <tr  v-if="index >= displaypost && index < (displaypost)+postnum">
                    <td >{{cmt.id}}</td>
                    <td >{{cmt.content}}</td>
                    <td >{{cmt.regdate}}</td>
                </tr>
                
                </tbody>
               
            </table>
            
        </div>
        <div class="row" id="comment_box3">
                <div class="col">
                    <div class="pagination" style="margin-left:-10px;">
                   <h1 style="display:none">{{num}}</h1>
                        <span class="page-item">
                         <button class="page-link" style="width:70px;"  v-if="this.startpagenum != 1" @click="prev">prev</button>
                    </span>
                    
                    <span class="page-item" v-for="index in endpagenum" :key="index" >
                        <button class="page-link" v-if="index >= startpagenum && index < startpagenum+pagenum_cnt && index <= pagenum" @click="pagechange(index)">{{index}}</button>
                    </span>
                    <span class="page-item">
                    <button class="page-link" style="width:70px;" v-if="startpagenum != pagenum - (pagenum%pagenum_cnt) +1" @click="next">next</button>

                    </span>

                </div>
                </div>
                
            </div>
        <div>

        </div>
    </div>
</template>

<script>
import {mapActions,mapState} from 'vuex'
export default {
    data() {
        return {
            num:1,
            content:"",
            count:"",
            postnum:5,
            pagenum:"",
            displaypost:"",
            pagenum_cnt:10,
            endpagenum:"",
            endpagenum_tmp:"",
            startpagenum:"",
        }
    },
    computed:{
        ...mapState(['comment_list']),
        
    },
    mounted() {
        
    },
    beforeUpdate() {
        this.count = this.comment_list.length;
        this.pagenum = Math.ceil(this.count/this.postnum);
        this.displaypost = (this.num - 1) * this.postnum;
        this.endpagenum = Math.ceil(this.num / this.pagenum_cnt ) * this.pagenum_cnt;
        this.startpagenum = this.endpagenum - (this.pagenum_cnt - 1);
        this.endpagenum_tmp = Math.ceil(this.count / this.pagenum_cnt);
        // if(this.endpagenum > this.endpagenum_tmp){
        //     this.endpagenum = this.endpagenum_tmp;
        // }
        if(this.pagenum < 10){
            this.endpagenum = this.pagenum;
        }
       

    },
    methods: {
        ...mapActions(['register_comment','get_comment']),
        
        commentreg(){
            if(this.$session.exists() == true){
                this.register_comment({
                    preidx:this.$route.query.idx,
                    id: this.$session.get('user').id,
                    content: this.content,
                });
            this.$router.go(this.$router.currentRoute);
            }else{
                alert('로그인후 작성해주세요');
            }
            
        },
        pagechange(index){
            this.num = index;
            this.displaypost = (this.num - 1) * this.postnum;
            
        },
        next(){
        this.num = this.endpagenum +1;
        this.displaypost = (this.num - 1) * this.postnum;
        
   
        
        },
        prev(){  
       
        this.num = this.startpagenum -1;
        this.displaypost = (this.num - 1) * this.postnum;
        
      
            
        },
        
       
      
      
    },
    created() {
        
        this.get_comment(this.$route.query.idx);
       
        
    },
    
}
</script>

<style>
    #comment_wrap{
        margin-top: 50px;
        
    }

    #comment_box1{
        margin-left: 100px;
    }

    #comment_box1 label{
        font-size: 25px;
        font-weight: 600;
    }
     #comment_box1 textarea{
        margin-top:20px;
        font-size: 15px;
        padding:20px;
        width:1000px;
        border-radius: 10px;
    }
    #comment_box1_1{
        margin-top: 22px;
        margin-right: 420px;
    }
     #comment_box1_1 button{
        width: 100px;
        height: 50px;
        margin-left: 910px;
    }
    #comment_box2{
        margin-top: 30px;
        margin-left: 110px;
    }
     #comment_box3{
        margin-top: 20px;
        margin-left: 110px;
    }
</style>