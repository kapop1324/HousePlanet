import Vue from "vue";
import Vuex from "vuex";
import http from "@/util/http-common";
import router from "@/router/index.js";

Vue.use(Vuex);

let store = new Vuex.Store({
  state: {
    user: {
      id: { type: String },
      pw: { type: String },
      user_name: { type: String },
      age: { type: Number },
      email: { type: String },
      role: { type: String },
    },
    login: {
      id: { type: String },
      pw: { type: String },
      user_name: { type: String },
      age: { type: Number },
      email: { type: String },
      role: { type: String },
    },
    review: {
      city: { type: String },
      gugun: { type: String },
      dong: { type: String },
      apt_name: { type: String },
      content: { type: String },
      rate: { type: Number },
    },
    citylist: {
      sido_code: { type: String },
      sido_name: { type: String },
    },
    gugunlist: {
      gugun_code: { type: String },
      gugun_name: { type: String },
    },
    donglist: {
      dongcode: { type: String },
      city: { type: String },
      gugun: { type: String },
      dong: { type: String },
    },
    review_list: [],
    review_detail: {
      idx: { type: Number },
      city: { type: String },
      gugun: { type: String },
      dong: { type: String },
      apt_name: { type: String },
      content: { type: String },
      rate: { type: Number },
      regdate: { type: String },
      id: { type: String },
    },
    comment_list: [],
    comment: {
      idx: { type: Number },
      preidx: { type: Number },
      id: { type: String },
      content: { type: String },
      regdate: { type: String },
    },
    notice: {
      idx: { type: Number },
      title: { type: String },
      id: { type: String },
      content: { type: String },
      regdate: { type: String },
    },
    notice_list: [],
    notice_detail: {
      idx: { type: Number },
      title: { type: String },
      id: { type: String },
      content: { type: String },
      regdate: { type: String },
    },
    high_rating: [],
    currentnum: 1,
    filteredApts: [],
    aptList: [],
    apts: [],
    apt: [],
    cities: [],
    guguns: [],
    dongs: [],
    city: "",
    gugun: "",
    dong: "",
    mapLoc: {
      center: {
        lat: 36,
        lng: 127,
      },
      zoom: 16,
    },
    markers: [],
    showFilter: false,
    showList: false,
    price: "",
    size: "",
    completedDate: "",
  },
  getters: {
    getReviews(state) {
      if (state.apt.length > 0) {
        let retList = [];
        let aptCode =
          state.apt[0].법정동시군구코드.toString() + state.apt[0].법정동읍면동코드.toString();
        console.log(aptCode);
        for (let i = 0; i < state.review_list.length; i++) {
          if (
            state.review_list[i].dong === aptCode &&
            state.review_list[i].apt_name === state.apt[0].아파트
          ) {
            retList.push(state.review_list[i]);
          }
        }
        return retList;
      }
      return [];
    },
  },
  mutations: {
    REGISTER_USER(state, data) {
      state.user = data;
    },
    REGISTER_REVIEW(state, data) {
      state.review = data;
    },
    LOGIN_USER(state, data) {
      state.login = data;
      store._vm.$session.set("user", data);
      console.log(store._vm.$session.get("user"));
    },
    SIDO_LIST(state, data) {
      state.citylist = data;
      console(state.citylist);
    },

    GUGUN_LIST(state, data) {
      state.gugunlist = data;
    },
    DONG_LIST(state, data) {
      state.donglist = data;
    },
    RIEVIEW_LIST(state, data) {
      state.review_list = data;
    },
    RIEVIEW_DETAIL(state, data) {
      state.review_detail = data;
    },
    COMMENT_LIST(state, data) {
      state.comment_list = data;
    },
    COMMENT(state, data) {
      state.comment = data;
    },
    DELETE_REVIEW(state, data) {
      for (let i = 0; i < state.review_list.length; i++) {
        if (state.review_list[i].idx == data.idx) {
          state.review_list.splice(i);
          break;
        }
      }
    },
    MODIFY_REVIEW(state, data) {
      for (let i = 0; i < state.review_list.length; i++) {
        if (state.review_list[i].idx == data.idx) {
          state.review_list[i].content = data.content;
          break;
        }
      }
    },
    NOTICE_LIST(state, data) {
      state.notice_list = data;
    },
    NOTICE_DETAIL(state, data) {
      state.notice_detail = data;
    },
    DELETE_NOTICE(state, data) {
      for (let i = 0; i < state.notice_list.length; i++) {
        if (state.notice_list[i].idx == data.idx) {
          state.notice_list.splice(i);
          break;
        }
      }
    },

    MODIFY_NOTICE(state, data) {
      for (let i = 0; i < state.notice_list.length; i++) {
        if (state.notice_list[i].idx == data.idx) {
          state.notice_list[i].content = data.content;
          state.notice_list[i].title = data.title;
          break;
        }
      }
    },
    GET_HIGHRATING(state, data) {
      state.high_rating = data;
    },
    NUM(state, data) {
      state.currentnum = data;
    },
    GET_MAP_CENTER(state, center) {
      state.mapLoc.center = center;
    },
    GET_MAP_ZOOM(state, zoom) {
      state.mapLoc.zoom = zoom;
    },
    CLEAR_MARKERS(state) {
      state.markers = [];
    },
    ADD_MARKER(state, marker) {
      state.markers.push(marker);
    },
    GET_CITY_LIST(state, cities) {
      state.cities = cities;
    },
    GET_GUGUN_LIST(state, guguns) {
      state.guguns = guguns;
      state.dongs = [];
    },
    GET_DONG_LIST(state, dongs) {
      state.dongs = dongs;
    },

    GET_APT_LIST(state, apts) {
      state.apts = apts;
      state.apt = [];
    },
    GET_APTS(state, aptList) {
      console.log(aptList);
      state.aptList = aptList;
    },
    SELECT_APT(state, apt) {
      state.apt = apt;
    },
    CLICK_FILTER(state) {
      state.showFilter = !state.showFilter;
    },
    SHOW_LIST(state) {
      state.showList = true;
    },
    HIDE_LIST(state) {
      state.showList = false;
    },
    SET_FILTER(state, filter) {
      state.showFilter = false;
      state.size = filter.size;
      state.price = filter.price;
      state.completedDate = filter.completedDate;
    },
    ON_FILTER(state) {
      state.apt = [];
      let temp = [];
      if (state.size != "") {
        let size = parseInt(state.size) * 10;
        if (size == 60) {
          for (let i = 0; i < state.aptList.length; i++) {
            let roomSize = state.aptList[i].전용면적 * 0.3025;
            if (roomSize >= size) {
              temp.push(state.aptList[i]);
            }
          }
        } else {
          for (let i = 0; i < state.aptList.length; i++) {
            let roomSize = state.aptList[i].전용면적 * 0.3025;
            if (roomSize >= size && roomSize < size + 10) {
              temp.push(state.aptList[i]);
            }
          }
        }
      } else {
        for (let i = 0; i < state.aptList.length; i++) {
          temp.push(state.aptList[i]);
        }
      }
      console.log(temp);
      if (state.price != "") {
        let price = parseInt(state.price);
        if (price != 300) {
          for (let i = 0; i < temp.length; i++) {
            let pri = parseInt(temp[i].거래금액.replace(",", "")) / 10000;
            console.log(pri);
            if (pri > price) {
              temp.splice(temp.indexOf(temp[i]), 1);
              i--;
            }
          }
        } else {
          price /= 10;
          for (let i = 0; i < temp.length; i++) {
            let pri = temp[i].거래금액 / 10000;
            if (pri < price) {
              temp.splice(temp.indexOf(temp[i]), 1);
              i--;
            }
          }
        }
      }
      console.log(temp);
      if (state.completedDate != "") {
        let date = 2021 - parseInt(state.completedDate);
        for (let i = 0; i < temp.length; i++) {
          if (temp[i].건축년도 < date) {
            temp.splice(temp.indexOf(temp[i]), 1);
            i--;
          }
        }
      }
      console.log(temp);
      let retList = [];
      for (let i = 0; i < temp.length; i++) {
        let isOk = false;
        for (let j = 0; j < retList.length; j++) {
          if (retList[j][0].아파트 == temp[i].아파트) {
            retList[j].push(temp[i]);
            isOk = true;
          }
        }
        if (!isOk) {
          retList.push([temp[i]]);
        }
      }
      state.filteredApts = retList;
    },
    SHOW_APT_DETAIL(state, apt) {
      state.apt = apt;
    },
  },
  actions: {
    change_num({ commit }, data) {
      commit("NUM", data);
    },

    register({ commit }, data) {
      http
        .post("/user/register", data)
        .then(({ data }) => {
          if (data === "success") {
            alert("회원가입 성공!");
            router.push({ name: "index" });
          }
        })

        .catch((error) => {
          alert("회원가입 실패!");
          console.dir(error);
        });
      commit("REGISTER_USER", data);
    },

    user_login({ commit }, data) {
      http
        .get("/user/login", {
          params: {
            id: data.id,
            pw: data.pw,
          },
        })
        .then((response) => {
          if (response.data.id === data.id) {
            console.log(response.data.role);
            alert("로그인 성공!");
            commit("LOGIN_USER", response.data);
            router.push({ name: "index" });
          } else {
            alert("로그인 실패!");
          }
        })
        .catch((error) => {
          console.dir(error);
          alert("로그인 실패!");
        });
    },

    getcity({ commit }) {
      http
        .get("/apt/city")
        .then((response) => {
          commit("SIDO_LIST", response.data);
        })
        .catch((error) => {
          console.dir(error);
        });
    },

    search_gugun({ commit }, city) {
      http
        .get(`/apt/gugun/${city}`)
        .then((response) => {
          commit("GUGUN_LIST", response.data);
          console.log(response);
        })
        .catch((error) => {
          console.dir(error);
        });
    },

    search_dong({ commit }, gugun) {
      http
        .get(`/apt/dong/${gugun}`)
        .then((response) => {
          commit("DONG_LIST", response.data);
          console.log(response);
        })
        .catch((error) => {
          console.dir(error);
        });
    },

    register_board({ commit }, data) {
      http
        .post("/apt/review", data)
        .then(({ data }) => {
          if (data === "success") {
            alert("등록 성공!");
            router.push({ name: "board" });
          }
        })
        .catch((error) => {
          alert("등록 실패!");
          console.dir(error);
        });
      commit("REGISTER_REVIEW", data);
    },

    getreview({ commit }) {
      http
        .get(`/apt/review_list`)
        .then((response) => {
          commit("RIEVIEW_LIST", response.data);
          console.log(response);
        })
        .catch((error) => {
          console.dir(error);
        });
    },

    getreviewdetail({ commit }, idx) {
      http
        .get(`/apt/detail/${idx}`)
        .then((response) => {
          commit("RIEVIEW_DETAIL", response.data);
          console.log(response);
        })
        .catch((error) => {
          console.dir(error);
        });
    },

    register_comment({ commit }, data) {
      http
        .post("/apt/reg_comment", data)
        .then(({ data }) => {
          if (data == "success") {
            alert("등록 성공!");
          }
        })
        .catch((error) => {
          alert("등록 실패!");
          console.dir(error);
        });
      commit("COMMENT", data);
    },

    get_comment({ commit }, preidx) {
      http
        .get(`/apt/get_comment/${preidx}`)
        .then((response) => {
          commit("COMMENT_LIST", response.data);
          console.log(response);
        })
        .catch((error) => {
          console.dir(error);
        });
    },

    delete_review({ commit }, idx) {
      http
        .delete(`/apt/delete_review/${idx}`)
        .then((response) => {
          console.log(response);
          alert("게시글이 삭제되었습니다.");
          router.push({ name: "board" });
        })
        .catch((error) => {
          console.dir(error);
        });
      commit("DELETE_REVIEW", idx);
    },
    modify_review({ commit }, data) {
      http
        .put(`/apt/modify_review`, data)
        .then((response) => {
          console.log(response);
          alert("게시글이 수정되었습니다.");
          router.push("/boarddetail?idx=" + data.idx);
        })
        .catch((error) => {
          console.dir(error);
        });
      commit("MODIFY_REVIEW", data);
    },

    reg_notice({ commit }, data) {
      http
        .post("/notice/reg_notice", data)
        .then(({ data }) => {
          if (data == "success") {
            alert("등록 성공!");
            router.push("/notice");
          }
        })
        .catch((error) => {
          alert("등록 실패!");
          console.dir(error);
        });
      commit("COMMENT", data);
    },

    get_notice({ commit }) {
      http
        .get(`/notice/get_notice/`)
        .then((response) => {
          commit("NOTICE_LIST", response.data);
          console.log(response);
        })
        .catch((error) => {
          console.dir(error);
        });
    },

    search_notice({ commit }, idx) {
      http
        .get(`/notice/search_notice/${idx}`)
        .then((response) => {
          commit("NOTICE_DETAIL", response.data);
          console.log(response);
        })
        .catch((error) => {
          console.dir(error);
        });
    },

    delete_notice({ commit }, idx) {
      http
        .delete(`/notice/delete_notice/${idx}`)
        .then((response) => {
          console.log(response);
          alert("공지사항이이 삭제되었습니다.");

          commit("DELETE_NOTICE", idx);
          router.push({ name: "notice" });
        })
        .catch((error) => {
          console.dir(error);
        });
    },

    modify_notice({ commit }, data) {
      http
        .put(`/notice/modify_notice`, data)
        .then((response) => {
          console.log(response);
          alert("공지사항이 수정되었습니다.");
          router.push("/noticedetail?idx=" + data.idx);
        })
        .catch((error) => {
          console.dir(error);
        });
      commit("MODIFY_NOTICE", data);
    },

    get_highrating({ commit }) {
      http
        .get(`/apt/highrating`)
        .then((response) => {
          commit("GET_HIGHRATING", response.data);
        })
        .catch((error) => {
          console.dir(error);
        });
    },

    moveMap({ commit }, location) {
      const SERVICE_KEY = "AIzaSyCUxGixwZeVBlQ0SjP3kD4ff-f--81mvv4";
      //console.log(location);
      http
        .get(
          "https://maps.googleapis.com/maps/api/geocode/json?address=" +
            location +
            "&key=" +
            SERVICE_KEY
        )
        .then((response) => {
          commit("GET_MAP_CENTER", response.data.results[0].geometry.location);
        })
        .catch((error) => {
          console.dir(error);
        });
    },
    addMarker({ commit }, apt) {
      const SERVICE_KEY = "AIzaSyCUxGixwZeVBlQ0SjP3kD4ff-f--81mvv4";

      http
        .get(
          "https://maps.googleapis.com/maps/api/geocode/json?address=" + apt + "&key=" + SERVICE_KEY
        )
        .then((response) => {
          commit("ADD_MARKER", response.data.results[0].geometry.location);
        })
        .catch((error) => {
          console.dir(error);
        });
    },
    getCityList({ commit }) {
      http
        .get("/apt/city2")
        .then((response) => {
          console.log(response.data);
          commit("GET_CITY_LIST", response.data);
        })
        .catch((error) => {
          console.dir(error);
        });
    },
    getGugunList({ commit }, city) {
      http
        .get(`/apt/gugun2/${city}`)
        .then((response) => {
          commit("GET_GUGUN_LIST", response.data);
        })
        .catch((error) => {
          console.dir(error);
        });
    },
    getDongList({ commit }, gugun) {
      http
        .get(`/apt/dong2/${gugun}`)
        .then((response) => {
          commit("GET_DONG_LIST", response.data);
        })
        .catch((error) => {
          console.dir(error);
        });
    },
    getAptListByDong({ commit, dispatch }, dongCode) {
      console.log(this.dongcode);
      const SERVICE_KEY =
        "SmiJotyPCTcu5wBRXCDfC2MEkhyvd0V%2BUDKavdZUeQh3D8vrjBHMrjfwQghBLAx50FJSvGc%2FlXMoJ1a6iUeHig%3D%3D";

      const SERVICE_URL =
        "http://openapi.molit.go.kr/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTradeDev";
      const params = {
        LAWD_CD: dongCode.substring(0, 5),
        DEAL_YMD: "202010",
        serviceKey: decodeURIComponent(SERVICE_KEY),
      };

      http
        .get(SERVICE_URL, {
          params,
        })
        .then((response) => {
          console.log(response);
          let aptList = response.data.response.body.items.item;
          let retList = [];
          let temp = [];
          let dong = dongCode.substring(5);
          for (let i = 0; i < aptList.length; i++) {
            if (aptList[i].법정동읍면동코드 == dong) {
              let isOk = false;
              for (let j = 0; j < retList.length; j++) {
                if (retList[j][0].아파트 == aptList[i].아파트) {
                  retList[j].push(aptList[i]);
                  isOk = true;
                }
              }
              if (!isOk) {
                retList.push([aptList[i]]);
              }
              temp.push(aptList[i]);
            }
          }
          dispatch("clearMarkers");
          for (let i = 0; i < retList.length; i++) {
            dispatch("addMarker", retList[i][0].도로명.trim());
          }
          commit("GET_APT_LIST", retList);
          commit("GET_APTS", temp);
          commit("ON_FILTER");
          commit("GET_MAP_ZOOM", 16);
        })
        .catch((error) => {
          console.dir(error);
        });
    },
    getAptListByGugun({ commit, dispatch }, gugunCode) {
      const SERVICE_KEY =
        "SmiJotyPCTcu5wBRXCDfC2MEkhyvd0V%2BUDKavdZUeQh3D8vrjBHMrjfwQghBLAx50FJSvGc%2FlXMoJ1a6iUeHig%3D%3D";

      const SERVICE_URL =
        "http://openapi.molit.go.kr/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTradeDev";
      const params = {
        LAWD_CD: gugunCode,
        DEAL_YMD: "202010",
        serviceKey: decodeURIComponent(SERVICE_KEY),
      };

      http
        .get(SERVICE_URL, {
          params,
        })
        .then((response) => {
          console.log(response);
          let aptList = response.data.response.body.items.item;
          let retList = [];
          for (let i = 0; i < aptList.length; i++) {
            let isOk = false;
            for (let j = 0; j < retList.length; j++) {
              if (retList[j][0].아파트 == aptList[i].아파트) {
                retList[j].push(aptList[i]);
                isOk = true;
              }
            }
            if (!isOk) {
              retList.push([aptList[i]]);
            }
          }
          dispatch("clearMarkers");
          for (let i = 0; i < retList.length; i++) {
            dispatch("addMarker", retList[i][0].도로명.trim());
          }
          commit("GET_APT_LIST", retList);
          commit("GET_APTS", aptList);
          commit("ON_FILTER");
          commit("GET_MAP_ZOOM", 14);
        })
        .catch((error) => {
          console.dir(error);
        });
    },
    clearMarkers({ commit }) {
      commit("CLEAR_MARKERS");
    },
    selectApt({ commit }, apt) {
      commit("SELECT_APT", apt);
    },
    clickFilter({ commit }) {
      commit("CLICK_FILTER");
    },
    setFilter({ commit }, filter) {
      console.log(filter.price);
      commit("SET_FILTER", filter);
      commit("ON_FILTER");
    },

    showAptDetail({ commit }, apt) {
      commit("SHOW_APT_DETAIL", apt);
    },
    showAptList({ commit }) {
      commit("SHOW_LIST");
    },
    hideAptList({ commit }) {
      commit("HIDE_LIST");
    },
  },
});
export default store;
