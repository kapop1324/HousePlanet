import Vue from "vue";
import VueRouter from "vue-router";
import index from "@/views/Index.vue";
import login from "@/views/login.vue";
import register from "@/views/register.vue";
import board from "@/views/board.vue";
import boardregister from "@/views/boardregister.vue";
import boarddetail from "@/views/boarddetail.vue";
import boardmodify from "@/views/boardmodify.vue";
import notice from "@/views/notice.vue";
import noticeregister from "@/views/noticeregister.vue";
import noticedetail from "@/views/noticedetail.vue";
import noticemodify from "@/views/noticemodify.vue";
import Apt from "../views/Apt.vue";
Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "index",
    component: index,
  },
  {
    path: "/login",
    name: "login",
    component: login,
      
  },
  {
    path: "/register",
    name: "register",
    component: register,
      
  },
  {
    path: "/board",
    name: "board",
    component: board,
      
  },
  {
    path: "/boardregister",
    name: "boardregister",
    component: boardregister,
      
  },
  {
    path: "/boarddetail",
    name: "boarddetail",
    component: boarddetail,
      
  },
  {
    path: "/boardmodify",
    name: "boardmodify",
    component: boardmodify,
      
  },
  {
    path: "/notice",
    name: "notice",
    component: notice,
      
  },
  {
    path: "/noticeregister",
    name: "noticeregister",
    component: noticeregister,
      
  },
  {
    path: "/noticedetail",
    name: "noticedetail",
    component: noticedetail,
      
  },
  
  {
    path: "/noticemodify",
    name: "noticemodify",
    component: noticemodify,
      
  },
  {
    path: "/apt",
    name: "Apt",
    component: Apt,
  },
 
    
    
  
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
