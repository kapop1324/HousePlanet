<template >
  <div style="margin-bottom:500px;">
    <modify></modify>
  </div>
  
</template>

<script>
import Modify from "@/components/Boardmodifyform.vue";
export default {
    components:{
        Modify
       
     
    }

}
</script>

<style>

</style>