<template>
  <div>
    <div class="row">
      <div class="col-md-4" id="map_maincol1">
        <apt-search-bar />
        <apt-filter v-if="showFilter"></apt-filter>
      </div>
      <div class="col-md-8" id="map_maincol2">
        <div class="container">
          <div class="row">
            <div class="col-6">
              <google-map />
            </div>
            <div class="col-6">
              <apt-list />
              <apt-detail :apt="apt" v-if="apt.length > 0" />
            </div>
          </div>
          <apt-board></apt-board>
          <div class="row" v-if="apt.length > 0">
            <apt-charts></apt-charts>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
import { mapActions } from "vuex";
import AptSearchBar from "@/components/apt/AptSearchBar.vue";
import AptList from "@/components/apt/AptList.vue";
import GoogleMap from "@/components/map/GoogleMap.vue";
import AptDetail from "@/components/apt/AptDetail.vue";
import AptFilter from "@/components/apt/AptFilter.vue";
import AptCharts from "@/components/apt/AptCharts.vue";
import AptBoard from "@/components/apt/AptBoard.vue";
export default {
  name: "Apt",
  data() {
    return {
      chartData: {
        Books: 24,
        Magazine: 30,
        Nuewspapers: 10,
      },
    };
  },
  components: {
    AptSearchBar,
    AptList,
    GoogleMap,
    AptDetail,
    AptFilter,
    AptCharts,
    AptBoard,
  },

  computed: {
    ...mapState(["showFilter", "apt", "showList"]),
  },
  methods: {
    ...mapActions(["getreview"]),
  },
  created() {
    this.getreview();
  },
};
</script>

<style>
#map_maincol1 {
  height: 1800px;
  margin: 0px;
  padding: 0px;
  background-color: mediumaquamarine;
}
</style>
