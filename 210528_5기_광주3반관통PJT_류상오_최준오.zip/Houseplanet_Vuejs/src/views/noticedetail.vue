<template>
<div style="margin-bottom:500px;">
       <notice-detail></notice-detail>
    </div>
  
</template>

<script>
import NoticeDetail from '@/components/NoticeDetailitem';
export default {
    components:{
        NoticeDetail,
    }
}
</script>

<style>

</style>