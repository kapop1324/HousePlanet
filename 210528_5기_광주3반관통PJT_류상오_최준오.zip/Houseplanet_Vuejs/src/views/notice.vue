<template >
 <div style="margin-bottom:500px;">
        <notice></notice>
    </div>
    
</template>

<script>
import Notice from "@/components/NoticeItem.vue"
export default {
    components:{
        Notice,
    }

}
</script>

<style>

</style>