<template >
  <div style="margin-bottom:500px;">
    <register-form></register-form>
  </div>
</template>

<script>
import RegisterForm from "@/components/Form.vue";
export default {
  name: 'read',
  components: {
    RegisterForm,
  },
  methods: {
    
  },
  created(){
  
  }
};
</script>

<style></style>
