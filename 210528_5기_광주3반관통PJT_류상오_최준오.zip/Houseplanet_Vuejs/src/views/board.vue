<template>
  <div style="margin-bottom:500px;">
      <board-item></board-item>
  </div>
</template>

<script>
import BoardItem from "@/components/BoardItem.vue";
export default {
    name: 'board',
    components:{
        BoardItem,

    }

}
</script>

<style>

</style>