<template >
    <div style="margin-bottom:500px;">
        <notice-form></notice-form>
    </div>
   
</template>

<script>
import NoticeForm from "@/components/NoticeForm.vue";
export default {

    components:{
        NoticeForm,
    }

}
</script>

<style>

</style>