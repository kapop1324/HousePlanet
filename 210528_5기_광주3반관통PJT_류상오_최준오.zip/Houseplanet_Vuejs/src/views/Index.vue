<template>
  <div style="margin-bottom:500px;">
    <div class="row" id="main_head">
      <h1>HOUSE PLANET</h1>
      <apt-main-search-bar></apt-main-search-bar>
    </div>
    <div class="container">
      <div class="row" id="main_body">
        <div class="col">
          <div class="row">
            <label>HIGH RATING</label>
          </div>
          <div class="row" id="main_highrating">
            <table class="table table-borderless table-hover" style="width: 400px">
              <thead>
                <tr> 
                  <th style="width: 40%">Apt</th>
                  <th style="width: 60%">Dong</th>
                </tr>
              </thead>
              <tbody v-for="(rev, index) in high_rating" :key="index">
                <tr v-if="index < 5">
                  <td>
        
                      
{{ rev.apt_name }}
                    
                  </td>
                  <td>{{ rev.dong }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="col">
          <div class="row">
            <div class="col">
              <label>REVIEW</label>
              <button class="btn btn-secondary">
                <router-link style="text-decoration: none; color: white" :to="`/board`"
                  >더보기</router-link
                >
              </button>
            </div>
          </div>
          <div class="row">
            <div class="row" id="main_board">
              <table class="table table-borderless table-hover" style="width: 400px">
                <thead>
                  <tr>
                    <th style="width: 40%">Apt</th>
                    <th style="width: 60%">Rating</th>
                  </tr>
                </thead>
                <tbody v-for="(rev, index) in review_list" :key="index">
                  <tr v-if="index < 5">
                    <td>
                      <router-link
                        style="text-decoration: none; color: black"
                        :to="`/boarddetail?idx=${rev.idx}`"
                        >{{ rev.apt_name }}</router-link
                      >
                    </td>
                    <td id="rate" v-if="rev.rate == 1">★</td>
                    <td id="rate" v-else-if="rev.rate == 2">★★</td>
                    <td id="rate" v-else-if="rev.rate == 3">★★★</td>
                    <td id="rate" v-else-if="rev.rate == 4">★★★★</td>
                    <td id="rate" v-else-if="rev.rate == 5">★★★★★</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="row">
            <div class="col">
              <label>NOTICE</label>
              <button class="btn btn-secondary">
                <router-link style="text-decoration: none; color: white" :to="`/notice`"
                  >더보기</router-link
                >
              </button>
            </div>
          </div>
          <div class="row" id="main_notice">
            <table class="table table-borderless table-hover" style="width: 400px">
              <thead>
                <tr>
                  <th style="width: 50%">TITLE</th>
                  <th style="width: 50%">REGDATE</th>
                </tr>
              </thead>
              <tbody v-for="(notice, index) in notice_list" :key="index">
                <tr v-if="index < 5">
                  <td>
                    <router-link
                      style="text-decoration: none; color: black"
                      :to="`/noticedetail?idx=${notice.idx}&&num=${num}`"
                      >{{ notice.title }}</router-link
                    >
                  </td>
                  <td>{{ notice.regdate }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="row"></div>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from "vuex";
import AptMainSearchBar from "@/components/apt/AptMainSearchBar.vue";
export default {
  name: "index",
  components: {
    AptMainSearchBar,
  },
  computed: {
    ...mapState(["review_list", "notice_list", "high_rating"]),
  },
  methods: {
    ...mapActions(["getreview", "get_notice", "get_highrating"]),
  },
  created() {
    this.getreview();
    this.get_notice();
    this.get_highrating();
  },
};
</script>

<style>
#main_head {
  margin: 0px;
  padding: 0px;
  background-image: url("../assets/main.jpg");
  background-size: cover;
  width: 100%;
  height: 1000px;
}
#main_head h1 {
  margin-top: 100px;
  font-size: 100px;
  margin-top: 14%;
  margin-left: 38%;
  color: white;
}

#main_body {
  margin-top: 100px;
}

#main_body label {
  font-size: 40px;
  font-weight: 600;
}

#main_body button {
  margin-left: 30px;
  margin-top: -20px;
}
#main_board,
#main_notice,
#main_highrating {
  margin-top: 30px;
  margin-left: 1px;
}
</style>
