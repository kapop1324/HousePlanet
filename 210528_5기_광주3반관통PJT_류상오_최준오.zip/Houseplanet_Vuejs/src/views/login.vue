<template>
  <div style="margin-bottom:500px;">
    <login-form></login-form>
  </div>
</template>

<script>
import LoginForm from "@/components/LoginForm.vue";

export default {
  name: 'login',
  components: {
    LoginForm,
  },
  methods: {
    
  },
  created(){
   
  }
};
</script>

<style></style>
