<template>
    <div style="margin-bottom:500px;">
        <board-detail></board-detail>
        <comment></comment>
    </div>
 
</template>

<script>
import BoardDetail from "@/components/detail.vue";
import Comment from "@/components/comment.vue";
export default {
    data() {
        return {
            
        }
    },
    components:{
        BoardDetail,
        Comment,
    }

}
</script>

<style>

</style>