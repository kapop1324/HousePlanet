<template>
    <div style="margin-bottom:500px;">
        <board-form></board-form>
    </div>
   
</template>

<script>
import BoardForm from "@/components/BoardForm.vue";
export default {

    components:{
        BoardForm,
    }

}
</script>

<style>

</style>