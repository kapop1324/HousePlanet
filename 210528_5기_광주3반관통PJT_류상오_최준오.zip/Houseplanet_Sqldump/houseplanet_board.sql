-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: houseplanet
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `city` varchar(20) NOT NULL,
  `gugun` varchar(20) NOT NULL,
  `dong` varchar(20) NOT NULL,
  `apt_name` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `rate` int NOT NULL,
  `regdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `id` varchar(20) NOT NULL,
  PRIMARY KEY (`idx`)
) ENGINE=InnoDB AUTO_INCREMENT=539 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (524,'1100000000','1111000000','1111011800','경희궁 파크팰리스','주변이 조용해서 살만합니다.',4,'2021-05-26 16:22:26','rso1129'),(525,'1100000000','1111000000','1111011800','경희궁 파크팰리스','사람살만한 곳입니다.',3,'2021-05-26 16:22:56','rso1129'),(527,'1100000000','1111000000','1111011800','경희궁 파크팰리스','아직까지는 살만합니다.',3,'2021-05-26 16:23:43','rso1129'),(528,'1100000000','1111000000','1111011800','경희궁 파크팰리스','주변에 상권이 좋습니다.',4,'2021-05-26 16:24:12','rso1129'),(529,'1100000000','1111000000','1111011800','경희궁 파크팰리스','살만합니다.',4,'2021-05-26 16:31:16','rso1129'),(530,'1100000000','1111000000','1111011800','경희궁 파크팰리스','살기에 좋은곳입니다.',4,'2021-05-26 16:32:20','rso1129'),(531,'1100000000','1111000000','1111016000','하이텍하우스','괜찮습니다.',3,'2021-05-26 20:19:09','rso1129'),(532,'1100000000','1114000000','1114012100','남산 SK LEADERS VIEW','살만합니다.',4,'2021-05-26 20:31:43','rso1129'),(533,'1100000000','1114000000','1114012100','남산 SK LEADERS VIEW','주변환경이 살기에 좋습니다.',4,'2021-05-26 20:32:35','rso1129'),(534,'1100000000','1126000000','1126010100','한신','건축년도가 너무 오래됐습니다.',2,'2021-05-26 20:33:38','rso1129'),(535,'1100000000','1126000000','1126010100','	용마산하늘채','비교적 최근에 지어져서 살기에 좋습니다.',5,'2021-05-26 20:34:32','rso1129');
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-27 11:17:54
